package org.example.cafearomaesabor.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class RootController {

    @GetMapping("/")
    public String acessoRaiz() {
        return "redirect:/login";
    }
}
