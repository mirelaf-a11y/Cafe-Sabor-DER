package org.example.cafearomaesabor.repository;

import org.example.cafearomaesabor.model.Produto;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

/**
 * Repository para operações de persistência da entidade Produto
 * Fornece métodos CRUD e consultas customizadas
 */
@Repository
public interface ProdutoRepository extends JpaRepository<Produto, Long> {
    /**
     * Busca produtos pelo nome
     * @param nome nome do produto
     * @return Lista de produtos encontrados
     */
    List<Produto> findByNomeContainingIgnoreCase(String nome);

    /**
     * Busca produtos abaixo do estoque mínimo
     * @return Lista de produtos com estoque crítico
     */
    List<Produto> findByQuantidadeAtualLessThanEqual(Integer estoqueMinimo);
}

