package org.example.cafearomaesabor.examples;

import org.example.cafearomaesabor.model.*;
import org.example.cafearomaesabor.repository.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

/**
 * EXEMPLOS DE USO DOS REPOSITORIES
 * ================================
 *
 * Este arquivo é apenas de referência
 * Mostra como utilizar os repositories injetados nos controllers
 */
public class ExemplosRepositories {

    // ============================================
    // USUARIOREPOSITORY - EXEMPLOS
    // ============================================

    public void exemplosUsuario(UsuarioRepository usuarioRepository) {

        // 1. Salvar novo usuário
        Usuario novoUsuario = new Usuario();
        novoUsuario.setNome("João Silva");
        novoUsuario.setLogin("joao.silva");
        novoUsuario.setSenha("senha123");
        usuarioRepository.save(novoUsuario);

        // 2. Buscar usuário por ID
        Optional<Usuario> usuario = usuarioRepository.findById(1L);
        if (usuario.isPresent()) {
            System.out.println("Usuário encontrado: " + usuario.get().getNome());
        }

        // 3. Buscar por login (método customizado)
        Usuario usuarioLogin = usuarioRepository.findByLogin("joao.silva");
        if (usuarioLogin != null) {
            System.out.println("Login encontrado: " + usuarioLogin.getId());
        }

        // 4. Listar todos os usuários
        List<Usuario> todosUsuarios = usuarioRepository.findAll();
        for (Usuario u : todosUsuarios) {
            System.out.println(u.getLogin());
        }

        // 5. Atualizar usuário
        if (usuario.isPresent()) {
            Usuario u = usuario.get();
            u.setNome("João Silva Atualizado");
            usuarioRepository.save(u);
        }

        // 6. Verificar se existe
        boolean existe = usuarioRepository.existsById(1L);
        System.out.println("Usuário existe: " + existe);

        // 7. Contar usuários
        long total = usuarioRepository.count();
        System.out.println("Total de usuários: " + total);

        // 8. Deletar por ID
        usuarioRepository.deleteById(1L);

        // 9. Deletar objeto
        if (usuario.isPresent()) {
            usuarioRepository.delete(usuario.get());
        }

        // 10. Deletar todos
        // usuarioRepository.deleteAll();
    }

    // ============================================
    // PRODUTOREPOSITORY - EXEMPLOS
    // ============================================

    public void exemplosProduto(ProdutoRepository produtoRepository) {

        // 1. Salvar novo produto
        Produto novoProduto = new Produto();
        novoProduto.setNome("Café Premium Arábica");
        novoProduto.setDescricao("Café 100% arábica de alta qualidade");
        novoProduto.setEstoqueMinimo(50);
        novoProduto.setLote("LOTE001");
        novoProduto.setDataValidade(LocalDate.of(2026, 12, 31));
        novoProduto.setQuantidadeAtual(150);
        produtoRepository.save(novoProduto);

        // 2. Buscar por ID
        Optional<Produto> produto = produtoRepository.findById(1L);
        if (produto.isPresent()) {
            System.out.println("Produto: " + produto.get().getNome());
        }

        // 3. Listar todos os produtos
        List<Produto> todosOsProdutos = produtoRepository.findAll();
        for (Produto p : todosOsProdutos) {
            System.out.println(p.getNome() + " - Quantidade: " + p.getQuantidadeAtual());
        }

        // 4. Buscar por nome (busca parcial, case-insensitive)
        List<Produto> cafesFindados = produtoRepository.findByNomeContainingIgnoreCase("café");
        for (Produto p : cafesFindados) {
            System.out.println("Encontrado: " + p.getNome());
        }

        // 5. IMPORTANTE: Buscar produtos com estoque crítico
        List<Produto> estoquesCriticos = produtoRepository.findByQuantidadeAtualLessThanEqual(50);
        for (Produto p : estoquesCriticos) {
            System.out.println("ALERTA: " + p.getNome() + " com apenas " + p.getQuantidadeAtual());
        }

        // 6. Atualizar quantidade de um produto
        if (produto.isPresent()) {
            Produto p = produto.get();
            p.setQuantidadeAtual(200);
            produtoRepository.save(p);
        }

        // 7. Deletar produto
        produtoRepository.deleteById(1L);

        // 8. Contar produtos
        long totalProdutos = produtoRepository.count();
        System.out.println("Total de produtos: " + totalProdutos);
    }

    // ============================================
    // MOVIMENTACAOESTOQUEREPOSITORY - EXEMPLOS
    // ============================================

    public void exemplosMovimentacao(
            MovimentacaoEstoqueRepository movimentacaoRepository,
            ProdutoRepository produtoRepository,
            UsuarioRepository usuarioRepository) {

        // 1. Registrar entrada de produto
        Optional<Produto> produto = produtoRepository.findById(1L);
        Optional<Usuario> usuario = usuarioRepository.findById(1L);

        if (produto.isPresent() && usuario.isPresent()) {
            MovimentacaoEstoque entrada = new MovimentacaoEstoque();
            entrada.setTipoMovimentacao(TipoMovimentacao.ENTRADA);
            entrada.setQuantidade(50);
            entrada.setDataMovimentacao(LocalDateTime.now());
            entrada.setProduto(produto.get());
            entrada.setUsuario(usuario.get());
            movimentacaoRepository.save(entrada);
        }

        // 2. Registrar saída de produto
        if (produto.isPresent() && usuario.isPresent()) {
            MovimentacaoEstoque saida = new MovimentacaoEstoque();
            saida.setTipoMovimentacao(TipoMovimentacao.SAIDA);
            saida.setQuantidade(10);
            saida.setDataMovimentacao(LocalDateTime.now());
            saida.setProduto(produto.get());
            saida.setUsuario(usuario.get());
            movimentacaoRepository.save(saida);
        }

        // 3. Buscar todas as movimentações
        List<MovimentacaoEstoque> todasAsMovimentacoes = movimentacaoRepository.findAll();
        for (MovimentacaoEstoque m : todasAsMovimentacoes) {
            System.out.println("Movimentação: " + m.getTipoMovimentacao() +
                             " - Quantidade: " + m.getQuantidade());
        }

        // 4. Buscar movimentações de um produto específico
        List<MovimentacaoEstoque> movimentacoesProduto =
            movimentacaoRepository.findByProdutoId(1L);
        for (MovimentacaoEstoque m : movimentacoesProduto) {
            System.out.println("Produto movimentado: " + m.getProduto().getNome());
        }

        // 5. Buscar movimentações de um usuário específico
        List<MovimentacaoEstoque> movimentacoesUsuario =
            movimentacaoRepository.findByUsuarioId(1L);
        for (MovimentacaoEstoque m : movimentacoesUsuario) {
            System.out.println("Registrado por: " + m.getUsuario().getNome());
        }

        // 6. Buscar apenas entradas
        List<MovimentacaoEstoque> entradas =
            movimentacaoRepository.findByTipoMovimentacao(TipoMovimentacao.ENTRADA);
        System.out.println("Total de entradas: " + entradas.size());

        // 7. Buscar apenas saídas
        List<MovimentacaoEstoque> saidas =
            movimentacaoRepository.findByTipoMovimentacao(TipoMovimentacao.SAIDA);
        System.out.println("Total de saídas: " + saidas.size());

        // 8. Buscar entradas de um produto específico
        List<MovimentacaoEstoque> entradasProduto =
            movimentacaoRepository.findByProdutoIdAndTipoMovimentacao(1L, TipoMovimentacao.ENTRADA);
        for (MovimentacaoEstoque m : entradasProduto) {
            System.out.println("Entrada: " + m.getQuantidade() +
                             " unidades em " + m.getDataMovimentacao());
        }

        // 9. Buscar por ID
        Optional<MovimentacaoEstoque> movimentacao = movimentacaoRepository.findById(1L);
        if (movimentacao.isPresent()) {
            MovimentacaoEstoque m = movimentacao.get();
            System.out.println("Movimentação ID " + m.getId() + ": " +
                             m.getTipoMovimentacao() + " de " + m.getQuantidade() + " unidades");
        }

        // 10. Deletar movimentação
        movimentacaoRepository.deleteById(1L);
    }

    // ============================================
    // EXEMPLO DE INTEGRAÇÃO EM CONTROLLER
    // ============================================

    /*
    @Controller
    @RequestMapping("/produto")
    public class ProdutoControllerExemplo {

        @Autowired
        private ProdutoRepository produtoRepository;

        @GetMapping
        public String listarProdutos(Model model) {
            // Buscar todos os produtos
            List<Produto> produtos = produtoRepository.findAll();

            // Produtos com estoque crítico
            List<Produto> estoqueCritico = produtoRepository.findByQuantidadeAtualLessThanEqual(50);

            // Passar para view
            model.addAttribute("produtos", produtos);
            model.addAttribute("estoqueCritico", estoqueCritico);

            return "produto/listagem";
        }

        @PostMapping("/form-inserir")
        public String procesarInserirProduto(@RequestParam String nome,
                                            @RequestParam String descricao,
                                            @RequestParam Integer estoqueMinimo,
                                            @RequestParam Integer quantidade) {
            Produto novo = new Produto();
            novo.setNome(nome);
            novo.setDescricao(descricao);
            novo.setEstoqueMinimo(estoqueMinimo);
            novo.setQuantidadeAtual(quantidade);

            produtoRepository.save(novo);

            return "redirect:/produto";
        }
    }
    */
}

