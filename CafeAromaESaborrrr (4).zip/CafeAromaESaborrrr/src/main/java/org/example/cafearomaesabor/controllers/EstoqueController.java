package org.example.cafearomaesabor.controllers;

import org.example.cafearomaesabor.model.MovimentacaoEstoque;
import org.example.cafearomaesabor.model.Produto;
import org.example.cafearomaesabor.model.TipoMovimentacao;
import org.example.cafearomaesabor.model.Usuario;
import org.example.cafearomaesabor.repository.MovimentacaoEstoqueRepository;
import org.example.cafearomaesabor.repository.ProdutoRepository;
import org.example.cafearomaesabor.repository.UsuarioRepository;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.server.ResponseStatusException;

import java.time.LocalDateTime;
import java.util.List;

import static org.springframework.http.HttpStatus.BAD_REQUEST;
import static org.springframework.http.HttpStatus.NOT_FOUND;

@Controller
@RequestMapping("/estoque")
public class EstoqueController {

    private final MovimentacaoEstoqueRepository movimentacaoEstoqueRepository;
    private final ProdutoRepository produtoRepository;
    private final UsuarioRepository usuarioRepository;

    public EstoqueController(MovimentacaoEstoqueRepository movimentacaoEstoqueRepository,
                             ProdutoRepository produtoRepository,
                             UsuarioRepository usuarioRepository) {
        this.movimentacaoEstoqueRepository = movimentacaoEstoqueRepository;
        this.produtoRepository = produtoRepository;
        this.usuarioRepository = usuarioRepository;
    }

    @GetMapping
    @Transactional(readOnly = true)
    public String mostrarEstoque(Model model) {
        List<MovimentacaoEstoque> movimentacoes =
                movimentacaoEstoqueRepository.findAllByOrderByDataMovimentacaoDesc();

        model.addAttribute("produtos", produtoRepository.findAll());
        model.addAttribute("movimentacoes", movimentacoes);
        model.addAttribute("totalProdutos", produtoRepository.count());
        model.addAttribute("totalEntradas", somarQuantidadePorTipo(TipoMovimentacao.ENTRADA));
        model.addAttribute("totalSaidas", somarQuantidadePorTipo(TipoMovimentacao.SAIDA));

        return "estoque/movimentacao";
    }

    @PostMapping("/movimentacao")
    @Transactional
    public String registrarMovimentacao(
            @RequestParam Long produtoId,
            @RequestParam TipoMovimentacao tipo,
            @RequestParam Integer quantidade) {

        if (quantidade == null || quantidade <= 0) {
            throw new ResponseStatusException(BAD_REQUEST, "Quantidade deve ser maior que zero");
        }

        Usuario usuario = obterUsuarioLogado();
        Produto produto = produtoRepository.findById(produtoId)
                .orElseThrow(() -> new ResponseStatusException(NOT_FOUND, "Produto não encontrado"));

        if (tipo == TipoMovimentacao.SAIDA && produto.getQuantidadeAtual() < quantidade) {
            throw new ResponseStatusException(BAD_REQUEST, "Estoque insuficiente para esta saída");
        }

        if (tipo == TipoMovimentacao.ENTRADA) {
            produto.setQuantidadeAtual(produto.getQuantidadeAtual() + quantidade);
        } else {
            produto.setQuantidadeAtual(produto.getQuantidadeAtual() - quantidade);
        }

        MovimentacaoEstoque movimentacao = new MovimentacaoEstoque();
        movimentacao.setTipoMovimentacao(tipo);
        movimentacao.setQuantidade(quantidade);
        movimentacao.setDataMovimentacao(LocalDateTime.now());
        movimentacao.setProduto(produto);
        movimentacao.setUsuario(usuario);

        produtoRepository.save(produto);
        movimentacaoEstoqueRepository.save(movimentacao);

        return "redirect:/estoque";
    }

    @PostMapping("/excluir")
    @Transactional
    public String excluirMovimentacao(@RequestParam Long id) {
        MovimentacaoEstoque movimentacao = movimentacaoEstoqueRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(NOT_FOUND, "Movimentação não encontrada"));

        Produto produto = movimentacao.getProduto();
        if (movimentacao.getTipoMovimentacao() == TipoMovimentacao.ENTRADA) {
            if (produto.getQuantidadeAtual() < movimentacao.getQuantidade()) {
                throw new ResponseStatusException(BAD_REQUEST, "Não é possível excluir: estoque ficaria negativo");
            }
            produto.setQuantidadeAtual(produto.getQuantidadeAtual() - movimentacao.getQuantidade());
        } else {
            produto.setQuantidadeAtual(produto.getQuantidadeAtual() + movimentacao.getQuantidade());
        }

        produtoRepository.save(produto);
        movimentacaoEstoqueRepository.delete(movimentacao);

        return "redirect:/estoque";
    }

    private int somarQuantidadePorTipo(TipoMovimentacao tipo) {
        return movimentacaoEstoqueRepository.findByTipoMovimentacao(tipo).stream()
                .mapToInt(MovimentacaoEstoque::getQuantidade)
                .sum();
    }

    private Usuario obterUsuarioLogado() {
        String username = SecurityContextHolder.getContext().getAuthentication().getName();
        Usuario usuario = usuarioRepository.findByLogin(username);
        if (usuario == null) {
            throw new ResponseStatusException(NOT_FOUND,
                    "Usuário não encontrado no banco para o login: " + username);
        }
        return usuario;
    }
}
