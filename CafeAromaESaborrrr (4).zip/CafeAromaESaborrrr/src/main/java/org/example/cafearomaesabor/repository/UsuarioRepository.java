package org.example.cafearomaesabor.repository;

import org.example.cafearomaesabor.model.Usuario;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * Repository para operações de persistência da entidade Usuario
 * Fornece métodos CRUD e consultas customizadas
 */
@Repository
public interface UsuarioRepository extends JpaRepository<Usuario, Long> {
    /**
     * Busca um usuário pelo login
     * @param login login do usuário
     * @return Usuario encontrado ou null
     */
    Usuario findByLogin(String login);
}

