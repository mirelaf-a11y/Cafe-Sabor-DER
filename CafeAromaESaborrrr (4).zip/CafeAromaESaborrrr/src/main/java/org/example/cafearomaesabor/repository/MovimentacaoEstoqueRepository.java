package org.example.cafearomaesabor.repository;

import org.example.cafearomaesabor.model.MovimentacaoEstoque;
import org.example.cafearomaesabor.model.TipoMovimentacao;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

/**
 * Repository para operações de persistência da entidade MovimentacaoEstoque
 * Fornece métodos CRUD e consultas customizadas
 */
@Repository
public interface MovimentacaoEstoqueRepository extends JpaRepository<MovimentacaoEstoque, Long> {
    /**
     * Busca todas as movimentações de um produto
     * @param produtoId id do produto
     * @return Lista de movimentações do produto
     */
    List<MovimentacaoEstoque> findByProdutoId(Long produtoId);

    /**
     * Busca todas as movimentações de um usuário
     * @param usuarioId id do usuário
     * @return Lista de movimentações do usuário
     */
    List<MovimentacaoEstoque> findByUsuarioId(Long usuarioId);

    /**
     * Busca movimentações por tipo (ENTRADA ou SAIDA)
     * @param tipoMovimentacao tipo da movimentação
     * @return Lista de movimentações do tipo especificado
     */
    List<MovimentacaoEstoque> findByTipoMovimentacao(TipoMovimentacao tipoMovimentacao);

    /**
     * Busca movimentações de um produto por tipo
     * @param produtoId id do produto
     * @param tipoMovimentacao tipo da movimentação
     * @return Lista de movimentações filtradas
     */
    List<MovimentacaoEstoque> findByProdutoIdAndTipoMovimentacao(Long produtoId, TipoMovimentacao tipoMovimentacao);

    List<MovimentacaoEstoque> findAllByOrderByDataMovimentacaoDesc();
}

