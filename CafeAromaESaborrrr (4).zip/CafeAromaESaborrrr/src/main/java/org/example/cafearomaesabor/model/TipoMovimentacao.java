package org.example.cafearomaesabor.model;

/**
 * Enum para tipos de movimentação de estoque
 * ENTRADA: Adição de produtos ao estoque
 * SAIDA: Remoção de produtos do estoque
 */
public enum TipoMovimentacao {
    ENTRADA("Entrada"),
    SAIDA("Saída");

    private final String descricao;

    TipoMovimentacao(String descricao) {
        this.descricao = descricao;
    }

    public String getDescricao() {
        return descricao;
    }
}

