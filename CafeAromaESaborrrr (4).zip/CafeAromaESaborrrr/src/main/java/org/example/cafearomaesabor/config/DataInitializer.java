package org.example.cafearomaesabor.config;

import org.example.cafearomaesabor.model.Produto;
import org.example.cafearomaesabor.model.Usuario;
import org.example.cafearomaesabor.repository.ProdutoRepository;
import org.example.cafearomaesabor.repository.UsuarioRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.time.LocalDate;

@Component
public class DataInitializer implements CommandLineRunner {

    private final UsuarioRepository usuarioRepository;
    private final ProdutoRepository produtoRepository;

    public DataInitializer(UsuarioRepository usuarioRepository, ProdutoRepository produtoRepository) {
        this.usuarioRepository = usuarioRepository;
        this.produtoRepository = produtoRepository;
    }

    @Override
    public void run(String... args) {
        if (usuarioRepository.count() == 0) {
            Usuario usuario1 = new Usuario();
            usuario1.setNome("Administrador");
            usuario1.setLogin("admin");
            usuario1.setSenha("admin123");
            usuarioRepository.save(usuario1);
        }

        if (produtoRepository.count() == 0) {
            produtoRepository.save(new Produto(null, "Café Premium Arábica",
                    "Café 100% arábica de alta qualidade", 50, "LOTE001",
                    LocalDate.of(2026, 12, 31), 150, null));
            produtoRepository.save(new Produto(null, "Café Robusta",
                    "Café robusta para bebidas fortes", 30, "LOTE002",
                    LocalDate.of(2026, 11, 30), 80, null));
        }
    }
}
