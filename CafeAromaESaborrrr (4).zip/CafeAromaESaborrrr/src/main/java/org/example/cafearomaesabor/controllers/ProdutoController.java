package org.example.cafearomaesabor.controllers;

import org.example.cafearomaesabor.model.Produto;
import org.example.cafearomaesabor.repository.ProdutoRepository;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.server.ResponseStatusException;

import java.time.LocalDate;

import static org.springframework.http.HttpStatus.NOT_FOUND;

@Controller
@RequestMapping("/produto")
public class ProdutoController {

    private final ProdutoRepository produtoRepository;

    public ProdutoController(ProdutoRepository produtoRepository) {
        this.produtoRepository = produtoRepository;
    }

    @GetMapping
    public String listarProdutos(Model model) {
        model.addAttribute("produtos", produtoRepository.findAll());
        return "produto/listagem";
    }

    @GetMapping("/form-inserir")
    public String mostrarFormularioInserir() {
        return "produto/form-inserir";
    }

    @PostMapping("/form-inserir")
    public String processarInserirProduto(
            @RequestParam String nome,
            @RequestParam(required = false) String descricao,
            @RequestParam Integer estoqueMinimo,
            @RequestParam(required = false) String lote,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate dataValidade,
            @RequestParam(defaultValue = "0") Integer quantidadeAtual) {

        Produto produto = new Produto();
        produto.setNome(nome);
        produto.setDescricao(descricao);
        produto.setEstoqueMinimo(estoqueMinimo);
        produto.setLote(lote);
        produto.setDataValidade(dataValidade);
        produto.setQuantidadeAtual(quantidadeAtual);

        produtoRepository.save(produto);
        return "redirect:/produto";
    }

    @GetMapping("/form-alterar")
    public String mostrarFormularioAlterar(@RequestParam Long id, Model model) {
        Produto produto = produtoRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(NOT_FOUND, "Produto não encontrado"));
        model.addAttribute("produto", produto);
        return "produto/form-alterar";
    }

    @PostMapping("/form-alterar")
    public String processarAlterarProduto(
            @RequestParam Long id,
            @RequestParam String nome,
            @RequestParam(required = false) String descricao,
            @RequestParam Integer estoqueMinimo,
            @RequestParam(required = false) String lote,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate dataValidade,
            @RequestParam Integer quantidadeAtual) {

        Produto produto = produtoRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(NOT_FOUND, "Produto não encontrado"));

        produto.setNome(nome);
        produto.setDescricao(descricao);
        produto.setEstoqueMinimo(estoqueMinimo);
        produto.setLote(lote);
        produto.setDataValidade(dataValidade);
        produto.setQuantidadeAtual(quantidadeAtual);

        produtoRepository.save(produto);
        return "redirect:/produto";
    }

    @PostMapping("/excluir")
    public String excluirProduto(@RequestParam Long id) {
        if (!produtoRepository.existsById(id)) {
            throw new ResponseStatusException(NOT_FOUND, "Produto não encontrado");
        }
        produtoRepository.deleteById(id);
        return "redirect:/produto";
    }
}
