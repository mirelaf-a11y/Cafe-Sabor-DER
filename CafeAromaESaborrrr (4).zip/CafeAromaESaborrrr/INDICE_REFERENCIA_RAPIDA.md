# 📇 ÍNDICE DE REFERÊNCIA - QUICK ACCESS

## 🎯 Acesso Rápido aos Arquivos

### 📌 COMECE AQUI
1. **README_IMPLEMENTACAO.md** - Start aqui! Quick start + Overview
2. **RESUMO_EXECUTIVO.md** - Visão geral do projeto
3. **ESTRUTURA_PROJETO.txt** - Estrutura visual

---

## 📚 POR TIPO DE NECESSIDADE

### 🔍 "Como fazer X?"

**"Como compilar o projeto?"**
→ README_IMPLEMENTACAO.md - Seção "Como Usar"
→ GUIA_TESTES.md - Etapa 2

**"Como injetar um repository?"**
→ README_IMPLEMENTACAO.md - Seção "Exemplo Rápido"
→ ExemplosRepositories.java - Linha ~85

**"Como registrar uma movimentação?"**
→ ExemplosRepositories.java - Linha ~180

**"Como consultar estoque crítico?"**
→ ExemplosRepositories.java - Linha ~115
→ ProdutoRepository.java - Método customizado

**"Como buscar movimentações de um usuário?"**
→ ExemplosRepositories.java - Linha ~220
→ MovimentacaoEstoqueRepository.java

**"Qual é o schema do banco?"**
→ SCHEMA_BANCO_DADOS.sql - Início do arquivo
→ ESTRUTURA_PROJETO.txt - Estrutura no Banco

---

## 📖 POR ARQUIVO

### 🔴 ENTIDADES

**Usuario.java**
- Localização: `src/main/java/org/example/cafearomaesabor/model/Usuario.java`
- Documentação: IMPLEMENTACAO_CAMADA_PERSISTENCIA.md - Seção 2.1
- 4 atributos + 1 relacionamento 1:N
- Código completo: Veja o arquivo

**Produto.java**
- Localização: `src/main/java/org/example/cafearomaesabor/model/Produto.java`
- Documentação: IMPLEMENTACAO_CAMADA_PERSISTENCIA.md - Seção 2.2
- 7 atributos + 1 relacionamento 1:N
- Código completo: Veja o arquivo

**MovimentacaoEstoque.java**
- Localização: `src/main/java/org/example/cafearomaesabor/model/MovimentacaoEstoque.java`
- Documentação: IMPLEMENTACAO_CAMADA_PERSISTENCIA.md - Seção 2.3
- 5 atributos + 2 relacionamentos N:1
- Código completo: Veja o arquivo

**TipoMovimentacao.java**
- Localização: `src/main/java/org/example/cafearomaesabor/model/TipoMovimentacao.java`
- Documentação: IMPLEMENTACAO_CAMADA_PERSISTENCIA.md - Seção 1
- Enum com ENTRADA/SAIDA
- Código completo: Veja o arquivo

---

### 🟢 REPOSITORIES

**UsuarioRepository.java**
- Localização: `src/main/java/org/example/cafearomaesabor/repository/UsuarioRepository.java`
- Documentação: IMPLEMENTACAO_CAMADA_PERSISTENCIA.md - Seção 3.1
- CRUD + findByLogin()
- Código completo: Veja o arquivo

**ProdutoRepository.java**
- Localização: `src/main/java/org/example/cafearomaesabor/repository/ProdutoRepository.java`
- Documentação: IMPLEMENTACAO_CAMADA_PERSISTENCIA.md - Seção 3.2
- CRUD + 2 métodos customizados
- Exemplo: ExemplosRepositories.java - Linha ~50

**MovimentacaoEstoqueRepository.java**
- Localização: `src/main/java/org/example/cafearomaesabor/repository/MovimentacaoEstoqueRepository.java`
- Documentação: IMPLEMENTACAO_CAMADA_PERSISTENCIA.md - Seção 3.3
- CRUD + 4 métodos customizados
- Exemplo: ExemplosRepositories.java - Linha ~140

---

### 🔵 CONTROLLERS ATUALIZADOS

**LoginController.java**
- Localização: `src/main/java/org/example/cafearomaesabor/controllers/LoginController.java`
- Documentação: IMPLEMENTACAO_CAMADA_PERSISTENCIA.md - Seção 4.1
- Injeção: UsuarioRepository
- Exemplo de uso: Veja o arquivo

**ProdutoController.java**
- Localização: `src/main/java/org/example/cafearomaesabor/controllers/ProdutoController.java`
- Documentação: IMPLEMENTACAO_CAMADA_PERSISTENCIA.md - Seção 4.2
- Injeção: ProdutoRepository
- Exemplo de uso: Veja o arquivo

**EstoqueController.java**
- Localização: `src/main/java/org/example/cafearomaesabor/controllers/EstoqueController.java`
- Documentação: IMPLEMENTACAO_CAMADA_PERSISTENCIA.md - Seção 4.3
- Injeção: MovimentacaoEstoqueRepository, ProdutoRepository
- Exemplo de uso: Veja o arquivo

---

## 📋 MÉTODOS DE QUERY

### UsuarioRepository
```sql
findByLogin(String login)
```
👉 Buscar usuário pelo login

### ProdutoRepository
```sql
findByNomeContainingIgnoreCase(String nome)
findByQuantidadeAtualLessThanEqual(Integer estoque)
```
👉 Busca de produtos

### MovimentacaoEstoqueRepository
```sql
findByProdutoId(Long id)
findByUsuarioId(Long id)
findByTipoMovimentacao(TipoMovimentacao tipo)
findByProdutoIdAndTipoMovimentacao(Long id, TipoMovimentacao tipo)
```
👉 Querys de movimentação

---

## 🔨 COMO FAZER COISAS COMUNS

### 1. Salvar um novo Produto

**Código:**
```java
@Autowired
private ProdutoRepository repo;

// Criar novo produto
Produto p = new Produto();
p.setNome("Café Premium");
p.setQuantidadeAtual(100);
p.setEstoqueMinimo(10);

// Salvar
repo.save(p);

// Ou retornar
Produto salvo = repo.save(p);
Long id = salvo.getId();
```

**Referência:** ExemplosRepositories.java - Linha 52

---

### 2. Listar todos os Produtos

**Código:**
```java
@Autowired
private ProdutoRepository repo;

List<Produto> todos = repo.findAll();
```

**Referência:** ExemplosRepositories.java - Linha 60

---

### 3. Buscar Produtos com Estoque Crítico

**Código:**
```java
@Autowired
private ProdutoRepository repo;

List<Produto> criticos = repo.findByQuantidadeAtualLessThanEqual(50);
for (Produto p : criticos) {
    System.out.println("ALERTA: " + p.getNome());
}
```

**Referência:** ExemplosRepositories.java - Linha 106

---

### 4. Registrar Movimentação de Entrada

**Código:**
```java
@Autowired
private MovimentacaoEstoqueRepository movRepo;
@Autowired
private ProdutoRepository prodRepo;
@Autowired
private UsuarioRepository usuRepo;

// Buscar produto e usuário
Produto produto = prodRepo.findById(1L).get();
Usuario usuario = usuRepo.findById(1L).get();

// Criar movimentação
MovimentacaoEstoque entrada = new MovimentacaoEstoque();
entrada.setTipoMovimentacao(TipoMovimentacao.ENTRADA);
entrada.setQuantidade(50);
entrada.setDataMovimentacao(LocalDateTime.now());
entrada.setProduto(produto);
entrada.setUsuario(usuario);

// Salvar
movRepo.save(entrada);
```

**Referência:** ExemplosRepositories.java - Linha 164

---

### 5. Listar Movimentações de um Produto

**Código:**
```java
@Autowired
private MovimentacaoEstoqueRepository repo;

List<MovimentacaoEstoque> movs = repo.findByProdutoId(1L);
```

**Referência:** ExemplosRepositories.java - Linha 218

---

## 🗄️ BANCO DE DADOS

### Tabelas Criadas
- `usuarios`
- `produtos`
- `movimentacoes_estoque`

### Criar Dados Manualmente
👉 SCHEMA_BANCO_DADOS.sql - Linha 70-90

### Consultas SQL Úteis
👉 SCHEMA_BANCO_DADOS.sql - Seção "CONSULTAS ÚTEIS"

### Views Criadas
👉 SCHEMA_BANCO_DADOS.sql - Seção "VIEWS ÚTEIS"

---

## 🧪 TESTES

### Testar Compilação
```bash
mvn clean install
```

### Testar Execução
```bash
mvn spring-boot:run
```

### Testar Banco
- Acedar: `http://localhost:8080/produto`
- Verificar que carrega

### Exemplos de Teste
👉 GUIA_TESTES.md - Seção "Teste de Integração"

---

## 🚨 PROBLEMAS & SOLUÇÕES

**Problema: Build falha**
→ GUIA_TESTES.md - "Solução de Problemas"

**Problema: Banco não cria**
→ README_IMPLEMENTACAO.md - Seção "Troubleshooting"

**Problema: Column not found**
→ CHECKLIST_ENTREGA.md - Verificação de anotações

---

## 📞 DOCUMENTAÇÃO PELO OBJETIVO

### "Quero entender a arquitetura"
1. RESUMO_EXECUTIVO.md - Seção "Destaques"
2. ESTRUTURA_PROJETO.txt - Fluxo de dados

### "Quero ver o código completo"
1. IMPLEMENTACAO_CAMADA_PERSISTENCIA.md - Seção 1-4
2. ExemplosRepositories.java - Todo o arquivo

### "Quero saber como usar"
1. README_IMPLEMENTACAO.md - Seção "Como Usar"
2. ExemplosRepositories.java - Exemplos práticos

### "Quero fazer testes"
1. GUIA_TESTES.md - Todo o arquivo
2. SCHEMA_BANCO_DADOS.sql - Consultas

### "Quero entregar na faculdade"
1. CHECKLIST_ENTREGA.md - Ver checklist
2. RESUMO_EXECUTIVO.md - Para apresentar

---

## 🔗 CORRESPONDÊNCIA ENTRE ARQUIVOS

| Conceito | Arquivo | Documentação |
|----------|---------|------------|
| Usuario | Usuario.java | IMPLEMENTACAO_CAMADA_PERSISTENCIA.md (2.1) |
| Produto | Produto.java | IMPLEMENTACAO_CAMADA_PERSISTENCIA.md (2.2) |
| Movimentação | MovimentacaoEstoque.java | IMPLEMENTACAO_CAMADA_PERSISTENCIA.md (2.3) |
| Repo Usuario | UsuarioRepository.java | IMPLEMENTACAO_CAMADA_PERSISTENCIA.md (3.1) |
| Repo Produto | ProdutoRepository.java | IMPLEMENTACAO_CAMADA_PERSISTENCIA.md (3.2) |
| Repo Mov | MovimentacaoEstoqueRepository.java | IMPLEMENTACAO_CAMADA_PERSISTENCIA.md (3.3) |
| Controller Login | LoginController.java | IMPLEMENTACAO_CAMADA_PERSISTENCIA.md (4.1) |
| Controller Prod | ProdutoController.java | IMPLEMENTACAO_CAMADA_PERSISTENCIA.md (4.2) |
| Controller Estoque | EstoqueController.java | IMPLEMENTACAO_CAMADA_PERSISTENCIA.md (4.3) |
| Banco | N/A | SCHEMA_BANCO_DADOS.sql |
| Exemplos | ExemplosRepositories.java | ExemplosRepositories.java |

---

## ⏱️ TEMPO ESTIMADO

| Atividade | Tempo | Referência |
|-----------|-------|-----------|
| Compilar | 1-2 min | README (Como Usar) |
| Iniciar app | 1 min | README (Como Usar) |
| Entender arquitetura | 10 min | RESUMO_EXECUTIVO |
| Entender código | 20 min | ExemplosRepositories |
| Fazer modificações | 15-30 min | Seu tempo |
| Testes | 10-15 min | GUIA_TESTES |

---

## 📊 ESTATÍSTICAS

| Item | Quantidade |
|------|-----------|
| Entidades | 4 |
| Repositories | 3 |
| Controllers Atualizados | 3 |
| Métodos Customizados | 7 |
| Arquivos de Documentação | 8 |
| Linhas de Código | ~1500 |
| Linhas de Documentação | ~3000 |

---

## 🎓 PARA APRESENTAÇÃO

**Slides sugeridos:**
1. Introdução (README_IMPLEMENTACAO)
2. Arquitetura (RESUMO_EXECUTIVO)
3. Modelo de Dados (ESTRUTURA_PROJETO)
4. Entidades (IMPLEMENTACAO_CAMADA_PERSISTENCIA)
5. Repositories (IMPLEMENTACAO_CAMADA_PERSISTENCIA)
6. Demo (Executar aplicação)

---

## 🔄 PRÓXIMAS ETAPAS

Após esta entrega, os próximos passos sugeridos são:

1. **Services** - Implementar regras de negócio
2. **DTOs** - Criar transfer objects
3. **Validações** - Validar dados
4. **Testes** - Testes unitários
5. **APIs REST** - Endpoints REST

---

## 🎯 INÍCIO RÁPIDO (5 MINUTOS)

1. Ler: README_IMPLEMENTACAO.md (2 min)
2. Compilar: `mvn clean install` (2 min)
3. Rodar: `mvn spring-boot:run` (1 min)

**Total: ~5 minutos**

---

**Desenvolvido:** 2026-05-18  
**Status:** ✅ Pronto para uso

