# ✅ CHECKLIST PRÉ-EXECUÇÃO

---

## 🔍 Verificação do Sistema

### Pré-Requisitos Instalados

- [ ] **Java**
  ```bash
  java -version
  # Deve ser 17+
  ```

- [ ] **Maven**
  ```bash
  mvn -version
  # Deve ser 3.6+
  ```

- [ ] **MySQL**
  ```bash
  mysql -u root -p -e "SHOW DATABASES;"
  # Digitará senha: Senai@2024
  ```

---

## 📁 Verificação do Projeto

- [ ] **Pasta Correta**
  ```
  C:\Users\TIDEV41\Documents\Spring SR 26\CafeAromaESabor
  ```

- [ ] **Arquivo pom.xml** (Build file)
  ```
  ✓ Existe
  ✓ Contém dependências Spring Boot
  ✓ Contém MySQL Driver
  ✓ Contém Lombok
  ```

- [ ] **Arquivo application.properties**
  ```
  src/main/resources/application.properties
  ✓ Existe
  ✓ URL: jdbc:mysql://localhost:3306/CafeAromaESabor
  ✓ Username: root
  ✓ Password: Senai@2024
  ```

- [ ] **Pasta src/main/java**
  ```
  ✓ model/ (4 arquivos .java)
  ✓ repository/ (3 arquivos .java)
  ✓ controllers/ (5 arquivos .java)
  ```

- [ ] **Pasta src/main/resources/templates**
  ```
  ✓ home.html
  ✓ login.html
  ✓ subpastas com .html
  ```

---

## 🗄️ Verificação do Banco de Dados

- [ ] **MySQL Servidor Rodando**
  ```bash
  # Teste conexão
  mysql -u root -p
  # Digite: Senai@2024
  ```

- [ ] **Usuário Root Existe**
  ```sql
  SHOW GRANTS FOR 'root'@'localhost';
  # Deve retornar grants
  ```

- [ ] **Banco Será Criado Automaticamente**
  ```
  (não precisa criar manualmente)
  ```

---

## 🔌 Verificação de Portas

- [ ] **Porta 3306 (MySQL)**
  ```bash
  # Windows
  netstat -ano | findstr :3306
  # Ou MySQL está rodando
  
  # Linux/Mac
  lsof -i :3306
  ```

- [ ] **Porta 8080 (Spring)**
  ```bash
  # Verificar disponibilidade
  netstat -ano | findstr :8080
  # Deve estar VAZIA (ou mudar porta)
  ```

---

## 🔧 Verificação de Configurações

- [ ] **application.properties**
  ```ini
  spring.datasource.url = CORRETO
  spring.datasource.username = root
  spring.datasource.password = Senai@2024
  spring.jpa.hibernate.ddl-auto = update
  server.port = 8080
  ```

- [ ] **Logging Configurado**
  ```
  ✓ ERROR/WARN: visível
  ✓ INFO: visível
  ✓ DEBUG: em /estoque e /app
  ✓ TRACE: para SQL
  ```

---

## 🎯 Verificação de Código

- [ ] **Entidades Criadas**
  - [ ] `Usuario.java` (com @OneToMany)
  - [ ] `Produto.java` (com @OneToMany)
  - [ ] `MovimentacaoEstoque.java` (com @ManyToOne x2)
  - [ ] `TipoMovimentacao.java` (Enum)

- [ ] **Repositórios Criados**
  - [ ] `UsuarioRepository.java` (JpaRepository)
  - [ ] `ProdutoRepository.java` (JpaRepository)
  - [ ] `MovimentacaoEstoqueRepository.java` (JpaRepository)

- [ ] **Controllers Atualizados**
  - [ ] `LoginController.java` (@Autowired)
  - [ ] `ProdutoController.java` (@Autowired)
  - [ ] `EstoqueController.java` (@Autowired x2)

---

## 🧪 Testes Rápidos

### Teste 1: Compilação Maven
```bash
mvn clean compile -q
```
**Esperado:** ✅ BUILD SUCCESS (sem erros)

- [ ] Sem erros de compilação
- [ ] Sem warnings críticos
- [ ] Dependências baixadas

### Teste 2: Execução Spring Boot
```bash
mvn spring-boot:run
```
**Esperado:** ✅ Tomcat started on port(s): 8080

- [ ] Aplicação inicia sem erros
- [ ] Banco conecta sem problemas
- [ ] Hibernate cria tabelas
- [ ] Porta 8080 disponível

### Teste 3: Tabelas Criadas
```bash
mysql -u root -p
USE CafeAromaESabor;
SHOW TABLES;
```
**Esperado:** ✅ 3 tabelas

- [ ] `usuarios`
- [ ] `produtos`
- [ ] `movimentacoes_estoque`

### Teste 4: HTTP Request
```bash
curl http://localhost:8080/login
```
**Esperado:** ✅ Página HTML da login

- [ ] Status 200 OK
- [ ] HTML retornado
- [ ] Sem erro 404

---

## 📊 Relatório de Status

| Item | Status | ✓/✗ |
|------|--------|-----|
| Java 17+ | | |
| Maven 3.6+ | | |
| MySQL 8.0+ | | |
| Projeto em local correto | | |
| pom.xml válido | | |
| application.properties correct | | |
| Código Java compilando | | |
| Tabelas criadas | | |
| Banco conectando | | |
| Porta 8080 disponível | | |
| Spring Boot iniciando | | |
| HTTP endpoints funcionando | | |

**Total de ✓ esperado: 12/12**

---

## 🚀 Procedimento Final

### Se TUDO está OK ✓

```bash
# 1. Terminal na pasta do projeto
cd "C:\Users\TIDEV41\Documents\Spring SR 26\CafeAromaESabor"

# 2. Executar
mvn spring-boot:run

# 3. Acessar
# Abra o navegador: http://localhost:8080/
```

### Se ALGO está errado ✗

| Problema | Solução |
|----------|---------|
| Java não encontrado | Instalar Java 17+ e adicionar ao PATH |
| Maven não encontrado | Instalar Maven e adicionar ao PATH |
| MySQL não conecta | Iniciar serviço MySQL |
| Porta 8080 em uso | Mudar em `application.properties` |
| Banco não cria | Verificar `ddl-auto=update` |
| Erro de compilação | Limpar: `mvn clean` |

---

## 📞 Ajuda Rápida

### Verificar tudo de uma vez (Windows PowerShell)

```powershell
# Java
java -version

# Maven
mvn -version

# MySQL conectar
mysql -u root -p -e "SHOW DATABASES;"

# Compilar
mvn clean compile

# Rodar entestes
mvn test

# Executar
mvn spring-boot:run
```

### Em Caso de Erro

```bash
# Limpar e recompilar
mvn clean

# Recompilar
mvn compile

# Executar com mais logs
mvn spring-boot:run -X
```

---

## ✅ Você Está Pronto Se:

- ✓ Todos os 12 itens da tabela estão marcados
- ✓ Compilação: BUILD SUCCESS
- ✓ Execução: Tomcat started on port 8080
- ✓ Banco: 3 tabelas criadas
- ✓ HTTP: Status 200 em /login

---

**Status:** 🟢 **PRONTO PARA USAR**

**Execute:** `mvn spring-boot:run`

**Acesse:** `http://localhost:8080/`


