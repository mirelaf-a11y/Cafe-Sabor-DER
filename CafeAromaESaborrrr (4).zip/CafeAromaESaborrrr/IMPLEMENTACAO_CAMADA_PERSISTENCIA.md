# Implementação - Camada de Modelagem e Persistência
## Sistema de Controle de Estoque - Cafe Aroma e Sabor

**Data:** 2026-05-18  
**Tecnologias:** Java 21 | Spring Boot 4.0.6 | JPA/Hibernate | MySQL | Lombok

---

## 📋 Estrutura de Diretórios Criada

```
com.cafeAromaESabor
│
├── model/
│   ├── Usuario.java
│   ├── Produto.java
│   ├── MovimentacaoEstoque.java
│   └── TipoMovimentacao.java (Enum)
│
├── repository/
│   ├── UsuarioRepository.java
│   ├── ProdutoRepository.java
│   └── MovimentacaoEstoqueRepository.java
│
└── controllers/ (Atualizado com @Autowired)
    ├── LoginController.java
    ├── ProdutoController.java
    └── EstoqueController.java
```

---

## 1️⃣ ENUM - TipoMovimentacao

**Arquivo:** `com.cafeAromaESabor.model.TipoMovimentacao`

Define os tipos de movimentação de estoque no sistema.

```java
package org.example.cafearomaesabor.model;

/**
 * Enum para tipos de movimentação de estoque
 * ENTRADA: Adição de produtos ao estoque
 * SAIDA: Remoção de produtos do estoque
 */
public enum TipoMovimentacao {
    ENTRADA("Entrada"),
    SAIDA("Saída");

    private final String descricao;

    TipoMovimentacao(String descricao) {
        this.descricao = descricao;
    }

    public String getDescricao() {
        return descricao;
    }
}
```

---

## 2️⃣ ENTIDADES

### 2.1 Usuario.java

**Arquivo:** `com.cafeAromaESabor.model.Usuario`

Representa os usuários do sistema que podem realizar movimentações de estoque.

```java
package org.example.cafearomaesabor.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.util.List;

/**
 * Entidade que representa um usuário do sistema
 * Responsável por realizar movimentações de estoque
 */
@Entity
@Table(name = "usuarios")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Usuario {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_usuario")
    private Long id;

    @Column(name = "nome", nullable = false, length = 100)
    private String nome;

    @Column(name = "login", nullable = false, unique = true, length = 50)
    private String login;

    @Column(name = "senha", nullable = false)
    private String senha;

    @OneToMany(mappedBy = "usuario", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<MovimentacaoEstoque> movimentacoes;
}
```

**Atributos:**
- `id`: Identificador único (PK)
- `nome`: Nome do usuário (até 100 caracteres)
- `login`: Login único (até 50 caracteres)
- `senha`: Senha do usuário
- `movimentacoes`: Lista de movimentações realizadas pelo usuário (relacionamento 1:N)

---

### 2.2 Produto.java

**Arquivo:** `com.cafeAromaESabor.model.Produto`

Representa os produtos cadastrados no sistema de estoque.

```java
package org.example.cafearomaesabor.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDate;
import java.util.List;

/**
 * Entidade que representa um produto do estoque
 * Armazena informações sobre produtos cadastrados no sistema
 */
@Entity
@Table(name = "produtos")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Produto {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_produto")
    private Long id;

    @Column(name = "nome", nullable = false, length = 150)
    private String nome;

    @Column(name = "descricao", columnDefinition = "TEXT")
    private String descricao;

    @Column(name = "estoque_minimo", nullable = false)
    private Integer estoqueMinimo;

    @Column(name = "lote", length = 50)
    private String lote;

    @Column(name = "data_validade")
    private LocalDate dataValidade;

    @Column(name = "quantidade_atual", nullable = false)
    private Integer quantidadeAtual;

    @OneToMany(mappedBy = "produto", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<MovimentacaoEstoque> movimentacoes;
}
```

**Atributos:**
- `id`: Identificador único (PK)
- `nome`: Nome do produto (até 150 caracteres)
- `descricao`: Descrição detalhada (campo TEXT)
- `estoqueMinimo`: Quantidade mínima permitida
- `lote`: Número do lote (até 50 caracteres)
- `dataValidade`: Data de validade do produto
- `quantidadeAtual`: Quantidade atual em estoque
- `movimentacoes`: Lista de movimentações do produto (relacionamento 1:N)

---

### 2.3 MovimentacaoEstoque.java

**Arquivo:** `com.cafeAromaESabor.model.MovimentacaoEstoque`

Representa as movimentações de entrada e saída de produtos no estoque.

```java
package org.example.cafearomaesabor.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDateTime;

/**
 * Entidade que representa uma movimentação de estoque
 * Registra entradas e saídas de produtos do estoque
 */
@Entity
@Table(name = "movimentacoes_estoque")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class MovimentacaoEstoque {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_movimentacao")
    private Long id;

    @Enumerated(EnumType.STRING)
    @Column(name = "tipo_movimentacao", nullable = false)
    private TipoMovimentacao tipoMovimentacao;

    @Column(name = "quantidade", nullable = false)
    private Integer quantidade;

    @Column(name = "data_movimentacao", nullable = false)
    private LocalDateTime dataMovimentacao;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "id_produto", nullable = false)
    private Produto produto;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "id_usuario", nullable = false)
    private Usuario usuario;
}
```

**Atributos:**
- `id`: Identificador único (PK)
- `tipoMovimentacao`: ENTRADA ou SAIDA (Enum)
- `quantidade`: Quantidade movimentada
- `dataMovimentacao`: Data e hora da movimentação
- `produto`: Produto relacionado (FK para Produto) - N:1
- `usuario`: Usuário que registrou (FK para Usuario) - N:1

---

## 3️⃣ REPOSITORIES

### 3.1 UsuarioRepository.java

**Arquivo:** `com.cafeAromaESabor.repository.UsuarioRepository`

```java
package org.example.cafearomaesabor.repository;

import org.example.cafearomaesabor.model.Usuario;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * Repository para operações de persistência da entidade Usuario
 * Fornece métodos CRUD e consultas customizadas
 */
@Repository
public interface UsuarioRepository extends JpaRepository<Usuario, Long> {
    /**
     * Busca um usuário pelo login
     * @param login login do usuário
     * @return Usuario encontrado ou null
     */
    Usuario findByLogin(String login);
}
```

**Métodos herdados de JpaRepository:**
- `save(Usuario)` - Salvar novo usuário
- `findById(Long)` - Buscar por ID
- `findAll()` - Listar todos
- `delete(Usuario)` - Deletar usuário
- `deleteById(Long)` - Deletar por ID

**Métodos customizados:**
- `findByLogin(String)` - Buscar usuário por login

---

### 3.2 ProdutoRepository.java

**Arquivo:** `com.cafeAromaESabor.repository.ProdutoRepository`

```java
package org.example.cafearomaesabor.repository;

import org.example.cafearomaesabor.model.Produto;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

/**
 * Repository para operações de persistência da entidade Produto
 * Fornece métodos CRUD e consultas customizadas
 */
@Repository
public interface ProdutoRepository extends JpaRepository<Produto, Long> {
    /**
     * Busca produtos pelo nome
     * @param nome nome do produto
     * @return Lista de produtos encontrados
     */
    List<Produto> findByNomeContainingIgnoreCase(String nome);

    /**
     * Busca produtos abaixo do estoque mínimo
     * @return Lista de produtos com estoque crítico
     */
    List<Produto> findByQuantidadeAtualLessThanEqual(Integer estoqueMinimo);
}
```

**Métodos customizados:**
- `findByNomeContainingIgnoreCase(String)` - Busca parcial por nome (case-insensitive)
- `findByQuantidadeAtualLessThanEqual(Integer)` - Produtos com estoque crítico

---

### 3.3 MovimentacaoEstoqueRepository.java

**Arquivo:** `com.cafeAromaESabor.repository.MovimentacaoEstoqueRepository`

```java
package org.example.cafearomaesabor.repository;

import org.example.cafearomaesabor.model.MovimentacaoEstoque;
import org.example.cafearomaesabor.model.TipoMovimentacao;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

/**
 * Repository para operações de persistência da entidade MovimentacaoEstoque
 * Fornece métodos CRUD e consultas customizadas
 */
@Repository
public interface MovimentacaoEstoqueRepository extends JpaRepository<MovimentacaoEstoque, Long> {
    /**
     * Busca todas as movimentações de um produto
     * @param produtoId id do produto
     * @return Lista de movimentações do produto
     */
    List<MovimentacaoEstoque> findByProdutoId(Long produtoId);

    /**
     * Busca todas as movimentações de um usuário
     * @param usuarioId id do usuário
     * @return Lista de movimentações do usuário
     */
    List<MovimentacaoEstoque> findByUsuarioId(Long usuarioId);

    /**
     * Busca movimentações por tipo (ENTRADA ou SAIDA)
     * @param tipoMovimentacao tipo da movimentação
     * @return Lista de movimentações do tipo especificado
     */
    List<MovimentacaoEstoque> findByTipoMovimentacao(TipoMovimentacao tipoMovimentacao);

    /**
     * Busca movimentações de um produto por tipo
     * @param produtoId id do produto
     * @param tipoMovimentacao tipo da movimentação
     * @return Lista de movimentações filtradas
     */
    List<MovimentacaoEstoque> findByProdutoIdAndTipoMovimentacao(Long produtoId, TipoMovimentacao tipoMovimentacao);
}
```

**Métodos customizados:**
- `findByProdutoId(Long)` - Movimentações por produto
- `findByUsuarioId(Long)` - Movimentações por usuário
- `findByTipoMovimentacao(TipoMovimentacao)` - Movimentações por tipo
- `findByProdutoIdAndTipoMovimentacao(Long, TipoMovimentacao)` - Movimentações filtradas

---

## 4️⃣ CONTROLLERS COM INJEÇÃO DE DEPENDÊNCIA

### 4.1 LoginController.java

```java
package org.example.cafearomaesabor.controllers;

import org.example.cafearomaesabor.repository.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/login")
public class LoginController {

    @Autowired
    private UsuarioRepository usuarioRepository;

    /**
     * Exibe a página de login
     */
    @GetMapping
    public String mostrarLogin() {
        return "login";
    }

    /**
     * Processa o login do usuário
     */
    @PostMapping
    public String procesarLogin() {
        // TODO: Implementar lógica de autenticação
        // Exemplo: usuarioRepository.findByLogin(login)
        return "redirect:/home";
    }
}
```

---

### 4.2 ProdutoController.java

```java
package org.example.cafearomaesabor.controllers;

import org.example.cafearomaesabor.repository.ProdutoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/produto")
public class ProdutoController {

    @Autowired
    private ProdutoRepository produtoRepository;

    /**
     * Exibe a listagem geral de produtos
     */
    @GetMapping
    public String listarProdutos() {
        // TODO: Buscar lista de produtos do banco de dados
        // Exemplo: produtoRepository.findAll()
        return "produto/listagem";
    }

    /**
     * Exibe o formulário para inserir um novo produto
     */
    @GetMapping("/form-inserir")
    public String mostrarFormularioInserir() {
        return "produto/form-inserir";
    }

    /**
     * Processa o envio do formulário de inserção de produto
     */
    @PostMapping("/form-inserir")
    public String procesarInserirProduto() {
        // TODO: Implementar lógica para salvar novo produto
        // Exemplo: produtoRepository.save(novoProduto)
        return "redirect:/produto";
    }

    /**
     * Exibe o formulário para alterar um produto
     */
    @GetMapping("/form-alterar")
    public String mostrarFormularioAlterar() {
        // TODO: Buscar dados do produto a ser alterado
        return "produto/form-alterar";
    }

    /**
     * Processa o envio do formulário de alteração de produto
     */
    @PostMapping("/form-alterar")
    public String procesarAlterarProduto() {
        // TODO: Implementar lógica para atualizar produto
        // Exemplo: produtoRepository.save(produtoAtualizado)
        return "redirect:/produto";
    }
}
```

---

### 4.3 EstoqueController.java

```java
package org.example.cafearomaesabor.controllers;

import org.example.cafearomaesabor.repository.MovimentacaoEstoqueRepository;
import org.example.cafearomaesabor.repository.ProdutoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/estoque")
public class EstoqueController {

    @Autowired
    private MovimentacaoEstoqueRepository movimentacaoEstoqueRepository;

    @Autowired
    private ProdutoRepository produtoRepository;

    /**
     * Exibe a página de gestão de estoque
     */
    @GetMapping
    public String mostrarEstoque() {
        // TODO: Buscar dados de estoque do banco de dados
        // Exemplo: movimentacaoEstoqueRepository.findAll()
        return "estoque/movimentacao";
    }
}
```

---

## 5️⃣ RELACIONAMENTOS E MAPEAMENTO

### Diagrama de Relacionamentos

```
┌──────────────┐          ┌──────────────┐
│   Usuario    │          │   Produto    │
├──────────────┤          ├──────────────┤
│ id (PK)      │          │ id (PK)      │
│ nome         │          │ nome         │
│ login        │          │ descricao    │
│ senha        │          │ estoqueMin   │
└──────────────┘          │ lote         │
       │                  │ dataValidade │
       │ 1               │ qtdAtual     │
       │                 └──────────────┘
       │                      │
       │ N                    │ 1
       │                      │
    ┌──────────────────────────────┐
    │ MovimentacaoEstoque          │
    ├──────────────────────────────┤
    │ id (PK)                      │
    │ tipoMovimentacao (ENUM)      │
    │ quantidade                   │
    │ dataMovimentacao             │
    │ id_usuario (FK)              │
    │ id_produto (FK)              │
    └──────────────────────────────┘
```

### Cardinalidade
- **Usuario → MovimentacaoEstoque:** 1:N (Um usuário registra várias movimentações)
- **Produto → MovimentacaoEstoque:** 1:N (Um produto tem várias movimentações)

---

## 6️⃣ CONFIGURAÇÃO DO BANCO DE DADOS

### application.properties

```properties
spring.application.name=CafeAromaESabor
spring.datasource.url=jdbc:mysql://localhost:3306/CafeAromaESabor?createDatabaseIfNotExist=true
spring.datasource.username=root
spring.datasource.password=Senai@2024
spring.datasource.driver-class-name=com.mysql.cj.jdbc.Driver

spring.jpa.generate-ddl=true
spring.jpa.hibernate.ddl-auto=update
spring.jpa.show-sql=true
spring.jpa.properties.hibernate.globally_quoted_identifiers=true
spring.jpa.properties.hibernate.globally_quoted_identifiers_skip_column_definitions=true
```

**Tabelas criadas automaticamente:**
- `usuarios` - Usuários do sistema
- `produtos` - Produtos cadastrados
- `movimentacoes_estoque` - Movimentações de estoque

---

## 7️⃣ EXEMPLO DE USO

### Injetar e usar o repository em um controller

```java
@Autowired
private ProdutoRepository produtoRepository;

// Listar todos os produtos
List<Produto> todos = produtoRepository.findAll();

// Buscar por ID
Optional<Produto> produto = produtoRepository.findById(1L);

// Buscar por nome
List<Produto> encontrados = produtoRepository.findByNomeContainingIgnoreCase("café");

// Salvar novo produto
Produto novo = new Produto();
novo.setNome("Café Premium");
novo.setQuantidadeAtual(100);
novo.setEstoqueMinimo(10);
produtoRepository.save(novo);

// Produtos com estoque crítico
List<Produto> critico = produtoRepository.findByQuantidadeAtualLessThanEqual(10);
```

---

## ✅ CHECKLIST DO PROJETO

- ✅ Entidades criadas com @Entity, @Table, @Id, @GeneratedValue
- ✅ Anotações Lombok aplicadas (@Data, @NoArgsConstructor, @AllArgsConstructor)
- ✅ Relacionamentos JPA configurados (@OneToMany, @ManyToOne)
- ✅ Enum TipoMovimentacao criado
- ✅ Repositories estendendo JpaRepository
- ✅ Controllers atualizados com @Autowired
- ✅ GenerationType.IDENTITY utilizado
- ✅ MySQL configurado como banco de dados
- ✅ DDL gerado automaticamente pelo Hibernate
- ✅ Sem autenticação JWT
- ✅ Sem criação de Services (por enquanto)
- ✅ Sem DTOs (por enquanto)
- ✅ Sem APIs REST completas (por enquanto)
- ✅ HTML/CSS mantidos intactos

---

## 📝 PRÓXIMAS ETAPAS (Futuro)

1. Implementar Services para lógica de negócio
2. Criar DTOs para transferência de dados
3. Adicionar validações com @Valid
4. Implementar paginação em consultas
5. Criar testes unitários e de integração
6. Adicionar logs com Slf4j
7. Implementar tratamento de exceções global

---

**Desenvolvido para:** Sistema de Controle de Estoque - Café Aroma e Sabor  
**Instituição:** SENAI  
**Componentes:** Spring Boot, JPA/Hibernate, Lombok, MySQL  

