# 💡 Exemplos Práticos: Implementação CRUD com Repositórios

## 📑 Índice
1. [Exemplos Básicos de CRUD](#exemplos-básicos-de-crud)
2. [Exemplos em Controllers](#exemplos-em-controllers)
3. [Exemplos Avançados](#exemplos-avançados)
4. [Validações e Tratamento de Erros](#validações-e-tratamento-de-erros)

---

## 🔷 Exemplos Básicos de CRUD

### **CREATE - Inserir novo Produto**

```java
@Autowired
private ProdutoRepository produtoRepository;

public void inserirNovoProduto() {
    // 1. Criar novo objeto
    Produto novoProduto = new Produto();
    
    // 2. Definir atributos
    novoProduto.setNome("Café Premium");
    novoProduto.setDescricao("Café importado de alta qualidade");
    novoProduto.setQuantidadeAtual(100);
    novoProduto.setEstoqueMinimo(50);
    novoProduto.setLote("CAFE001");
    novoProduto.setDataValidade(LocalDate.of(2027, 12, 31));
    
    // 3. Salvar no banco
    Produto produtoSalvo = produtoRepository.save(novoProduto);
    
    // 4. Verificar resultado
    System.out.println("Produto inserido com ID: " + produtoSalvo.getId());
}
```

---

### **CREATE - Inserir novo Usuário**

```java
@Autowired
private UsuarioRepository usuarioRepository;

public void inserirNovoUsuario() {
    Usuario novoUsuario = new Usuario();
    novoUsuario.setNome("João Silva");
    novoUsuario.setLogin("joao_silva");
    novoUsuario.setSenha("senha_segura_123");
    novoUsuario.setMovimentacoes(new ArrayList<>());  // Lista vazia
    
    Usuario usuarioSalvo = usuarioRepository.save(novoUsuario);
    System.out.println("Usuário criado: " + usuarioSalvo.getNome());
}
```

---

### **READ - Buscar um Produto por ID**

```java
public void buscarProdutoById() {
    Long produtoId = 1L;
    
    // Opção 1: com Optional
    Optional<Produto> produtoOpt = produtoRepository.findById(produtoId);
    
    if (produtoOpt.isPresent()) {
        Produto produto = produtoOpt.get();
        System.out.println("Encontrado: " + produto.getNome());
    } else {
        System.out.println("Produto não encontrado");
    }
    
    // Opção 2: com orElse (retorna null se não encontrar)
    Produto produto = produtoRepository.findById(produtoId).orElse(null);
    
    // Opção 3: com orElseThrow (lança exceção se não encontrar)
    Produto produto = produtoRepository.findById(produtoId)
        .orElseThrow(() -> new RuntimeException("Produto não encontrado"));
}
```

---

### **READ - Buscar Usuário por Login**

```java
public void buscarUsuarioPorLogin() {
    String login = "joao_silva";
    
    Usuario usuario = usuarioRepository.findByLogin(login);
    
    if (usuario != null) {
        System.out.println("Usuário encontrado: " + usuario.getNome());
    } else {
        System.out.println("Usuário não encontrado");
    }
}
```

---

### **READ - Listar Todos**

```java
public void listarTodosProdutos() {
    List<Produto> produtos = produtoRepository.findAll();
    
    System.out.println("Total de produtos: " + produtos.size());
    
    for (Produto p : produtos) {
        System.out.println(p.getNome() + " - Qtd: " + p.getQuantidadeAtual());
    }
}
```

---

### **READ - Buscar com Filtro**

```java
public void buscarProdutosPorNome() {
    String busca = "café";
    
    List<Produto> produtos = produtoRepository.findByNomeContainingIgnoreCase(busca);
    
    System.out.println("Encontrados " + produtos.size() + " produtos");
    
    for (Produto p : produtos) {
        System.out.println("- " + p.getNome());
    }
}
```

---

### **UPDATE - Atualizar Produto**

```java
public void atualizarProduto() {
    Long produtoId = 1L;
    
    // 1. Buscar produto
    Optional<Produto> produtoOpt = produtoRepository.findById(produtoId);
    
    if (produtoOpt.isPresent()) {
        Produto produto = produtoOpt.get();
        
        // 2. Modificar atributos
        produto.setNome("Café Premium Atualizado");
        produto.setQuantidadeAtual(150);
        produto.setEstoqueMinimo(60);
        
        // 3. Salvar atualização
        produtoRepository.save(produto);
        
        System.out.println("Produto atualizado com sucesso");
    }
}
```

---

### **DELETE - Deletar por ID**

```java
public void deletarProduto() {
    Long produtoId = 1L;
    
    produtoRepository.deleteById(produtoId);
    
    System.out.println("Produto deletado");
}
```

---

### **DELETE - Deletar Objeto**

```java
public void deletarProdutoObjeto() {
    Produto produto = produtoRepository.findById(1L).orElse(null);
    
    if (produto != null) {
        produtoRepository.delete(produto);
        System.out.println("Produto removido");
    }
}
```

---

### **DELETE - Deletar Todos**

```java
public void limparBancoDados() {
    produtoRepository.deleteAll();
    usuarioRepository.deleteAll();
    movimentacaoEstoqueRepository.deleteAll();
    
    System.out.println("Banco de dados limpo!");
}
```

---

## 🎯 Exemplos em Controllers

### **ProdutoController - Exemplo Completo**

```java
@Controller
@RequestMapping("/produto")
public class ProdutoController {
    
    @Autowired
    private ProdutoRepository produtoRepository;
    
    /**
     * GET /produto - Listar todos os produtos
     */
    @GetMapping
    public String listarProdutos(Model model) {
        // Buscar todos os produtos do banco
        List<Produto> produtos = produtoRepository.findAll();
        
        // Enviar para a view
        model.addAttribute("produtos", produtos);
        model.addAttribute("totalProdutos", produtos.size());
        
        return "produto/listagem";
    }
    
    /**
     * GET /produto/form-inserir - Exibir formulário de inserção
     */
    @GetMapping("/form-inserir")
    public String mostrarFormularioInserir(Model model) {
        // Adicionar novo objeto vazio para o formulário binding
        model.addAttribute("produto", new Produto());
        
        return "produto/form-inserir";
    }
    
    /**
     * POST /produto/form-inserir - Processar inserção
     */
    @PostMapping("/form-inserir")
    public String procesarInserirProduto(
        @ModelAttribute Produto produto,
        RedirectAttributes redirectAttributes
    ) {
        try {
            // Validar dados obrigatórios
            if (produto.getNome() == null || produto.getNome().isEmpty()) {
                redirectAttributes.addFlashAttribute("erro", "Nome é obrigatório");
                return "redirect:/produto/form-inserir";
            }
            
            // Salvar produto
            produtoRepository.save(produto);
            
            // Mensagem de sucesso
            redirectAttributes.addFlashAttribute("sucesso", 
                "Produto '" + produto.getNome() + "' inserido com sucesso!");
            
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("erro", 
                "Erro ao inserir produto: " + e.getMessage());
        }
        
        return "redirect:/produto";
    }
    
    /**
     * GET /produto/form-alterar/{id} - Exibir formulário de alteração
     */
    @GetMapping("/form-alterar/{id}")
    public String mostrarFormularioAlterar(
        @PathVariable Long id,
        Model model,
        RedirectAttributes redirectAttributes
    ) {
        // Buscar produto
        Optional<Produto> produtoOpt = produtoRepository.findById(id);
        
        if (produtoOpt.isPresent()) {
            model.addAttribute("produto", produtoOpt.get());
            return "produto/form-alterar";
        } else {
            redirectAttributes.addFlashAttribute("erro", "Produto não encontrado");
            return "redirect:/produto";
        }
    }
    
    /**
     * POST /produto/form-alterar - Processar alteração
     */
    @PostMapping("/form-alterar")
    public String procesarAlterarProduto(
        @ModelAttribute Produto produtoAtualizado,
        RedirectAttributes redirectAttributes
    ) {
        try {
            // Buscar produto existente
            Optional<Produto> produtoOpt = produtoRepository.findById(produtoAtualizado.getId());
            
            if (produtoOpt.isPresent()) {
                Produto produto = produtoOpt.get();
                
                // Atualizar campos
                produto.setNome(produtoAtualizado.getNome());
                produto.setDescricao(produtoAtualizado.getDescricao());
                produto.setQuantidadeAtual(produtoAtualizado.getQuantidadeAtual());
                produto.setEstoqueMinimo(produtoAtualizado.getEstoqueMinimo());
                produto.setLote(produtoAtualizado.getLote());
                produto.setDataValidade(produtoAtualizado.getDataValidade());
                
                // Salvar atualização
                produtoRepository.save(produto);
                
                redirectAttributes.addFlashAttribute("sucesso", 
                    "Produto '" + produto.getNome() + "' alterado com sucesso!");
            }
            
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("erro", 
                "Erro ao alterar produto: " + e.getMessage());
        }
        
        return "redirect:/produto";
    }
    
    /**
     * GET /produto/deletar/{id} - Deletar produto
     */
    @GetMapping("/deletar/{id}")
    public String deletarProduto(
        @PathVariable Long id,
        RedirectAttributes redirectAttributes
    ) {
        try {
            // Buscar produto
            Optional<Produto> produtoOpt = produtoRepository.findById(id);
            
            if (produtoOpt.isPresent()) {
                String nomeProduto = produtoOpt.get().getNome();
                
                // Deletar (cascata deleta movimentações também)
                produtoRepository.deleteById(id);
                
                redirectAttributes.addFlashAttribute("sucesso", 
                    "Produto '" + nomeProduto + "' deletado com sucesso!");
            }
            
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("erro", 
                "Erro ao deletar produto: " + e.getMessage());
        }
        
        return "redirect:/produto";
    }
}
```

---

### **EstoqueController - Exemplo Completo**

```java
@Controller
@RequestMapping("/estoque")
public class EstoqueController {
    
    @Autowired
    private MovimentacaoEstoqueRepository movimentacaoEstoqueRepository;
    
    @Autowired
    private ProdutoRepository produtoRepository;
    
    /**
     * GET /estoque - Exibir página de estoque
     */
    @GetMapping
    public String mostrarEstoque(Model model) {
        // Buscar todas as movimentações
        List<MovimentacaoEstoque> movimentacoes = movimentacaoEstoqueRepository.findAll();
        
        // Buscar produtos em estoque crítico
        List<Produto> produtosCriticos = 
            produtoRepository.findByQuantidadeAtualLessThanEqual(50);
        
        // Buscar todos os produtos
        List<Produto> todosProdutos = produtoRepository.findAll();
        
        // Contar movimentações por tipo
        List<MovimentacaoEstoque> entradas = 
            movimentacaoEstoqueRepository.findByTipoMovimentacao(TipoMovimentacao.ENTRADA);
        
        List<MovimentacaoEstoque> saidas = 
            movimentacaoEstoqueRepository.findByTipoMovimentacao(TipoMovimentacao.SAIDA);
        
        // Enviar para view
        model.addAttribute("movimentacoes", movimentacoes);
        model.addAttribute("produtosCriticos", produtosCriticos);
        model.addAttribute("todosProdutos", todosProdutos);
        model.addAttribute("totalEntradas", entradas.size());
        model.addAttribute("totalSaidas", saidas.size());
        
        return "estoque/movimentacao";
    }
    
    /**
     * POST /estoque/registrar-entrada - Registrar entrada de estoque
     */
    @PostMapping("/registrar-entrada")
    public String registrarEntrada(
        @RequestParam Long produtoId,
        @RequestParam Integer quantidade,
        @RequestParam Long usuarioId,
        RedirectAttributes redirectAttributes
    ) {
        try {
            // Buscar produto e usuário
            Optional<Produto> produtoOpt = produtoRepository.findById(produtoId);
            Optional<Usuario> usuarioOpt = usuarioRepository.findById(usuarioId);
            
            if (!produtoOpt.isPresent() || !usuarioOpt.isPresent()) {
                redirectAttributes.addFlashAttribute("erro", "Produto ou usuário não encontrado");
                return "redirect:/estoque";
            }
            
            Produto produto = produtoOpt.get();
            Usuario usuario = usuarioOpt.get();
            
            // Atualizar quantidade do produto
            produto.setQuantidadeAtual(produto.getQuantidadeAtual() + quantidade);
            produtoRepository.save(produto);
            
            // Registrar movimentação
            MovimentacaoEstoque movimentacao = new MovimentacaoEstoque();
            movimentacao.setProduto(produto);
            movimentacao.setUsuario(usuario);
            movimentacao.setTipoMovimentacao(TipoMovimentacao.ENTRADA);
            movimentacao.setQuantidade(quantidade);
            movimentacao.setDataMovimentacao(LocalDateTime.now());
            
            movimentacaoEstoqueRepository.save(movimentacao);
            
            redirectAttributes.addFlashAttribute("sucesso", 
                "Entrada de " + quantidade + " unidades registrada!");
            
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("erro", 
                "Erro ao registrar entrada: " + e.getMessage());
        }
        
        return "redirect:/estoque";
    }
    
    /**
     * POST /estoque/registrar-saida - Registrar saída de estoque
     */
    @PostMapping("/registrar-saida")
    public String registrarSaida(
        @RequestParam Long produtoId,
        @RequestParam Integer quantidade,
        @RequestParam Long usuarioId,
        RedirectAttributes redirectAttributes
    ) {
        try {
            // Buscar produto e usuário
            Optional<Produto> produtoOpt = produtoRepository.findById(produtoId);
            Optional<Usuario> usuarioOpt = usuarioRepository.findById(usuarioId);
            
            if (!produtoOpt.isPresent() || !usuarioOpt.isPresent()) {
                redirectAttributes.addFlashAttribute("erro", "Produto ou usuário não encontrado");
                return "redirect:/estoque";
            }
            
            Produto produto = produtoOpt.get();
            Usuario usuario = usuarioOpt.get();
            
            // Validar quantidade disponível
            if (produto.getQuantidadeAtual() < quantidade) {
                redirectAttributes.addFlashAttribute("erro", 
                    "Quantidade insuficiente. Disponível: " + produto.getQuantidadeAtual());
                return "redirect:/estoque";
            }
            
            // Atualizar quantidade do produto
            produto.setQuantidadeAtual(produto.getQuantidadeAtual() - quantidade);
            produtoRepository.save(produto);
            
            // Registrar movimentação
            MovimentacaoEstoque movimentacao = new MovimentacaoEstoque();
            movimentacao.setProduto(produto);
            movimentacao.setUsuario(usuario);
            movimentacao.setTipoMovimentacao(TipoMovimentacao.SAIDA);
            movimentacao.setQuantidade(quantidade);
            movimentacao.setDataMovimentacao(LocalDateTime.now());
            
            movimentacaoEstoqueRepository.save(movimentacao);
            
            redirectAttributes.addFlashAttribute("sucesso", 
                "Saída de " + quantidade + " unidades registrada!");
            
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("erro", 
                "Erro ao registrar saída: " + e.getMessage());
        }
        
        return "redirect:/estoque";
    }
}
```

---

### **LoginController - Exemplo Completo**

```java
@Controller
@RequestMapping("/login")
public class LoginController {
    
    @Autowired
    private UsuarioRepository usuarioRepository;
    
    /**
     * GET /login - Exibir página de login
     */
    @GetMapping
    public String mostrarLogin() {
        return "login";
    }
    
    /**
     * POST /login - Processar login
     */
    @PostMapping
    public String procesarLogin(
        @RequestParam String login,
        @RequestParam String senha,
        Model model,
        HttpSession session
    ) {
        // Buscar usuário no banco de dados
        Usuario usuario = usuarioRepository.findByLogin(login);
        
        if (usuario == null) {
            // Usuário não encontrado
            model.addAttribute("erro", "Login ou senha incorretos");
            return "login";
        }
        
        // Verificar senha (em produção, usar bcrypt!)
        if (!usuario.getSenha().equals(senha)) {
            model.addAttribute("erro", "Login ou senha incorretos");
            return "login";
        }
        
        // Autenticação bem-sucedida
        // Armazenar usuário na sessão
        session.setAttribute("usuarioLogado", usuario);
        
        return "redirect:/home";
    }
    
    /**
     * GET /logout - Fazer logout
     */
    @GetMapping("/logout")
    public String logout(HttpSession session) {
        // Remover usuário da sessão
        session.removeAttribute("usuarioLogado");
        session.invalidate();
        
        return "redirect:/login";
    }
    
    /**
     * GET /login/novo - Exibir formulário de registro
     */
    @GetMapping("/novo")
    public String mostrarRegistro(Model model) {
        model.addAttribute("usuario", new Usuario());
        return "login/registro";
    }
    
    /**
     * POST /login/novo - Processar registro de novo usuário
     */
    @PostMapping("/novo")
    public String procesarRegistro(
        @ModelAttribute Usuario usuario,
        RedirectAttributes redirectAttributes
    ) {
        try {
            // Validações
            if (usuario.getNome() == null || usuario.getNome().isEmpty()) {
                redirectAttributes.addFlashAttribute("erro", "Nome é obrigatório");
                return "redirect:/login/novo";
            }
            
            // Verificar se login já existe
            Usuario usuarioExistente = usuarioRepository.findByLogin(usuario.getLogin());
            if (usuarioExistente != null) {
                redirectAttributes.addFlashAttribute("erro", "Login já cadastrado");
                return "redirect:/login/novo";
            }
            
            // Salvar novo usuário
            usuarioRepository.save(usuario);
            
            redirectAttributes.addFlashAttribute("sucesso", 
                "Usuário '" + usuario.getNome() + "' registrado com sucesso!");
            
            return "redirect:/login";
            
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("erro", 
                "Erro ao registrar: " + e.getMessage());
            return "redirect:/login/novo";
        }
    }
}
```

---

## 🚀 Exemplos Avançados

### **Consultas Complexas com Repositórios**

```java
// Exemplo 1: Buscar movimentações de um produto com usuario eager loading
@Query("SELECT DISTINCT m FROM MovimentacaoEstoque m " +
       "JOIN FETCH m.usuario " +
       "WHERE m.produto.id = :produtoId " +
       "ORDER BY m.dataMovimentacao DESC")
List<MovimentacaoEstoque> findByProdutoIdComUsuario(@Param("produtoId") Long produtoId);

// Uso:
List<MovimentacaoEstoque> movs = movRepository.findByProdutoIdComUsuario(1L);
for (MovimentacaoEstoque m : movs) {
    System.out.println(m.getUsuario().getNome()); // Sem LazyInitializationException
}
```

---

### **Paginação de Resultados**

```java
// Adicionar método ao ProdutoRepository
public interface ProdutoRepository extends JpaRepository<Produto, Long> {
    Page<Produto> findByNomeContainingIgnoreCase(String nome, Pageable pageable);
}

// Uso em Controller:
@GetMapping("/page")
public String listarPaginado(
    @RequestParam(defaultValue = "0") int page,
    @RequestParam(defaultValue = "10") int size,
    Model model
) {
    Pageable pageable = PageRequest.of(page, size, Sort.by("nome").ascending());
    Page<Produto> pagina = produtoRepository.findAll(pageable);
    
    model.addAttribute("produtos", pagina.getContent());
    model.addAttribute("totalPages", pagina.getTotalPages());
    model.addAttribute("currentPage", page);
    
    return "produto/listagem";
}
```

---

### **Transações Customizadas**

```java
@Service
public class EstoqueService {
    
    @Autowired
    private ProdutoRepository produtoRepository;
    
    @Autowired
    private MovimentacaoEstoqueRepository movRepository;
    
    @Transactional
    public void transferirEstoque(Long produtoOrigemId, Long produtoDestinoId, Integer quantidade) {
        // Buscar produtos
        Produto origem = produtoRepository.findById(produtoOrigemId).orElse(null);
        Produto destino = produtoRepository.findById(produtoDestinoId).orElse(null);
        
        if (origem == null || destino == null) {
            throw new RuntimeException("Produto não encontrado");
        }
        
        // Validar quantidade
        if (origem.getQuantidadeAtual() < quantidade) {
            throw new RuntimeException("Quantidade insuficiente");
        }
        
        // Atualizar quantidades (tudo em 1 transação)
        origem.setQuantidadeAtual(origem.getQuantidadeAtual() - quantidade);
        destino.setQuantidadeAtual(destino.getQuantidadeAtual() + quantidade);
        
        produtoRepository.save(origem);
        produtoRepository.save(destino);
        
        // Se tudo passou, commit automático
        // Se erro em qualquer ponto, rollback de tudo
    }
}
```

---

## ✔️ Validações e Tratamento de Erros

### **Exemplo de Validação**

```java
@PostMapping("/form-inserir")
public String procesarInserirProduto(
    @ModelAttribute @Valid Produto produto,
    BindingResult result,
    RedirectAttributes redirectAttributes
) {
    // Verificar se há erros de validação
    if (result.hasErrors()) {
        return "produto/form-inserir";
    }
    
    // Se passou nas validações
    produtoRepository.save(produto);
    redirectAttributes.addFlashAttribute("sucesso", "Produto inserido!");
    
    return "redirect:/produto";
}
```

---

### **Entidade com Validações**

```java
@Entity
@Data
public class Produto {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @NotBlank(message = "Nome não pode ser vazio")
    @Length(min = 3, max = 150, message = "Nome deve ter entre 3 e 150 caracteres")
    private String nome;
    
    @NotNull(message = "Quantidade atual é obrigatória")
    @Min(value = 0, message = "Quantidade não pode ser negativa")
    private Integer quantidadeAtual;
    
    @NotNull(message = "Estoque mínimo é obrigatório")
    @Min(value = 1, message = "Estoque mínimo deve ser pelo menos 1")
    private Integer estoqueMinimo;
}
```

---

## 📊 Resumo de Padrões

| Padrão | Descrição | Exemplo |
|--------|-----------|---------|
| **CRUD Básico** | Create, Read, Update, Delete | save(), findById(), delete() |
| **Query Derivada** | Métodos gerados por convenção | findByNomeContaining() |
| **Transacional** | Múltiplas operações em 1 transação | @Transactional |
| **Paginação** | Resultados em páginas | Page<T>, Pageable |
| **Validação** | Validação de dados | @Valid, @NotNull |
| **Eager/Lazy** | Carregamento de relacionamentos | fetch = EAGER/LAZY |

---

**Status:** ✅ EXEMPLOS COMPLETOS PRONTOS PARA USAR


