# GUIA DE TESTES - SISTEMA DE ESTOQUE

## 📋 Verificação de Implementação

### ✅ Etapa 1: Verificar Estrutura de Pacotes

```
src/main/java/org/example/cafearomaesabor/
├── model/
│   ├── Usuario.java ✓
│   ├── Produto.java ✓
│   ├── MovimentacaoEstoque.java ✓
│   └── TipoMovimentacao.java ✓
│
├── repository/
│   ├── UsuarioRepository.java ✓
│   ├── ProdutoRepository.java ✓
│   └── MovimentacaoEstoqueRepository.java ✓
│
├── controllers/
│   ├── LoginController.java ✓ (com @Autowired)
│   ├── ProdutoController.java ✓ (com @Autowired)
│   ├── EstoqueController.java ✓ (com @Autowired)
│   ├── HomeController.java ✓
│   └── RootController.java ✓
│
└── examples/
    └── ExemplosRepositories.java ✓
```

---

## 🚀 Etapa 2: Compilar o Projeto

### Executar Maven Clean Install

```bash
cd "C:\Users\TIDEV41\Documents\Spring SR 26\CafeAromaESabor"
mvn clean install
```

**Resultado esperado:**
- Build SUCCESS
- Nenhum erro de compilação
- Todos os testes passos (se houver)

---

## 🗄️ Etapa 3: Verificar Banco de Dados

### Iniciar a Aplicação

1. Certifique-se que o MySQL está rodando
2. Banco de dados `CafeAromaESabor` será criado automaticamente
3. As tabelas serão criadas pelo Hibernate (ddl-auto=update)

### Validar Tabelas Criadas

Conectar ao MySQL e executar:

```sql
USE CafeAromaESabor;
SHOW TABLES;
```

**Tabelas esperadas:**
- ✓ usuarios
- ✓ produtos
- ✓ movimentacoes_estoque

---

## 📝 Etapa 4: Testar via Application

### 4.1 Teste de Inicialização

1. Executar a aplicação:
   ```bash
   mvn spring-boot:run
   ```

2. Acessar: `http://localhost:8080/`
   - ✓ Deve redirecionar para `/login`

3. Acessar: `http://localhost:8080/home`
   - ✓ Deve exibir página home

4. Acessar: `http://localhost:8080/produto`
   - ✓ Deve exibir página de listagem de produtos

5. Acessar: `http://localhost:8080/estoque`
   - ✓ Deve exibir página de movimentação de estoque

---

## 🔬 Etapa 5: Testes de Integração com Banco

### Criar um Teste de Repositório

Criar arquivo: `src/test/java/org/example/cafearomaesabor/RepositorioTest.java`

```java
package org.example.cafearomaesabor;

import org.example.cafearomaesabor.model.*;
import org.example.cafearomaesabor.repository.*;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@DataJpaTest
class RepositorioTest {

    @Autowired
    private UsuarioRepository usuarioRepository;

    @Autowired
    private ProdutoRepository produtoRepository;

    @Autowired
    private MovimentacaoEstoqueRepository movimentacaoRepository;

    // ==========================================
    // TESTES DE USUARIO
    // ==========================================

    @Test
    void testarSalvarUsuario() {
        // Arrange
        Usuario usuario = new Usuario();
        usuario.setNome("João Silva");
        usuario.setLogin("joao.silva");
        usuario.setSenha("senha123");

        // Act
        Usuario salvo = usuarioRepository.save(usuario);

        // Assert
        assertNotNull(salvo.getId());
        assertEquals("João Silva", salvo.getNome());
        assertEquals("joao.silva", salvo.getLogin());
    }

    @Test
    void testarBuscarUsuarioPorLogin() {
        // Arrange
        Usuario usuario = new Usuario();
        usuario.setNome("Maria Santos");
        usuario.setLogin("maria.santos");
        usuario.setSenha("senha456");
        usuarioRepository.save(usuario);

        // Act
        Usuario encontrado = usuarioRepository.findByLogin("maria.santos");

        // Assert
        assertNotNull(encontrado);
        assertEquals("Maria Santos", encontrado.getNome());
    }

    @Test
    void testarListarTodosUsuarios() {
        // Arrange
        Usuario u1 = new Usuario(null, "User1", "user1", "pass1", null);
        Usuario u2 = new Usuario(null, "User2", "user2", "pass2", null);
        usuarioRepository.save(u1);
        usuarioRepository.save(u2);

        // Act
        List<Usuario> usuarios = usuarioRepository.findAll();

        // Assert
        assertTrue(usuarios.size() >= 2);
    }

    // ==========================================
    // TESTES DE PRODUTO
    // ==========================================

    @Test
    void testarSalvarProduto() {
        // Arrange
        Produto produto = new Produto();
        produto.setNome("Café Premium");
        produto.setDescricao("Café arábica 100%");
        produto.setEstoqueMinimo(50);
        produto.setQuantidadeAtual(150);
        produto.setLote("LOTE001");
        produto.setDataValidade(LocalDate.of(2026, 12, 31));

        // Act
        Produto salvo = produtoRepository.save(produto);

        // Assert
        assertNotNull(salvo.getId());
        assertEquals("Café Premium", salvo.getNome());
        assertEquals(150, salvo.getQuantidadeAtual());
    }

    @Test
    void testarBuscarProdutoPorNome() {
        // Arrange
        Produto produto = new Produto();
        produto.setNome("Café Robusta");
        produto.setEstoqueMinimo(30);
        produto.setQuantidadeAtual(100);
        produtoRepository.save(produto);

        // Act
        List<Produto> encontrados = produtoRepository.findByNomeContainingIgnoreCase("Robusta");

        // Assert
        assertFalse(encontrados.isEmpty());
        assertEquals("Café Robusta", encontrados.get(0).getNome());
    }

    @Test
    void testarEstoqueCritico() {
        // Arrange
        Produto p1 = new Produto(null, "Produto1", "", 50, "", null, 30, null);
        Produto p2 = new Produto(null, "Produto2", "", 50, "", null, 60, null);
        produtoRepository.save(p1);
        produtoRepository.save(p2);

        // Act
        List<Produto> criticos = produtoRepository.findByQuantidadeAtualLessThanEqual(50);

        // Assert
        assertTrue(criticos.stream().anyMatch(p -> p.getNome().equals("Produto1")));
    }

    // ==========================================
    // TESTES DE MOVIMENTACAO
    // ==========================================

    @Test
    void testarRegistrarEntrada() {
        // Arrange
        Usuario usuario = new Usuario(null, "Admin", "admin", "pass", null);
        Produto produto = new Produto(null, "Café", "", 50, "", null, 100, null);
        usuarioRepository.save(usuario);
        produtoRepository.save(produto);

        MovimentacaoEstoque movimentacao = new MovimentacaoEstoque();
        movimentacao.setTipoMovimentacao(TipoMovimentacao.ENTRADA);
        movimentacao.setQuantidade(50);
        movimentacao.setDataMovimentacao(LocalDateTime.now());
        movimentacao.setUsuario(usuario);
        movimentacao.setProduto(produto);

        // Act
        MovimentacaoEstoque salva = movimentacaoRepository.save(movimentacao);

        // Assert
        assertNotNull(salva.getId());
        assertEquals(TipoMovimentacao.ENTRADA, salva.getTipoMovimentacao());
        assertEquals(50, salva.getQuantidade());
    }

    @Test
    void testarBuscarMovimentacoesPorProduto() {
        // Arrange
        Usuario usuario = new Usuario(null, "User", "user", "pass", null);
        Produto produto = new Produto(null, "Café", "", 50, "", null, 100, null);
        usuarioRepository.save(usuario);
        produtoRepository.save(produto);

        MovimentacaoEstoque mov1 = new MovimentacaoEstoque();
        mov1.setTipoMovimentacao(TipoMovimentacao.ENTRADA);
        mov1.setQuantidade(30);
        mov1.setDataMovimentacao(LocalDateTime.now());
        mov1.setUsuario(usuario);
        mov1.setProduto(produto);
        movimentacaoRepository.save(mov1);

        // Act
        List<MovimentacaoEstoque> movimentacoes = 
            movimentacaoRepository.findByProdutoId(produto.getId());

        // Assert
        assertFalse(movimentacoes.isEmpty());
        assertEquals(1, movimentacoes.size());
    }

    @Test
    void testarBuscarMovimentacoesPorTipo() {
        // Arrange
        Usuario usuario = new Usuario(null, "User", "user", "pass", null);
        Produto produto = new Produto(null, "Café", "", 50, "", null, 100, null);
        usuarioRepository.save(usuario);
        produtoRepository.save(produto);

        MovimentacaoEstoque entrada = new MovimentacaoEstoque();
        entrada.setTipoMovimentacao(TipoMovimentacao.ENTRADA);
        entrada.setQuantidade(50);
        entrada.setDataMovimentacao(LocalDateTime.now());
        entrada.setUsuario(usuario);
        entrada.setProduto(produto);

        MovimentacaoEstoque saida = new MovimentacaoEstoque();
        saida.setTipoMovimentacao(TipoMovimentacao.SAIDA);
        saida.setQuantidade(10);
        saida.setDataMovimentacao(LocalDateTime.now());
        saida.setUsuario(usuario);
        saida.setProduto(produto);

        movimentacaoRepository.save(entrada);
        movimentacaoRepository.save(saida);

        // Act
        List<MovimentacaoEstoque> entradas = 
            movimentacaoRepository.findByTipoMovimentacao(TipoMovimentacao.ENTRADA);
        List<MovimentacaoEstoque> saidas = 
            movimentacaoRepository.findByTipoMovimentacao(TipoMovimentacao.SAIDA);

        // Assert
        assertEquals(1, entradas.size());
        assertEquals(1, saidas.size());
    }
}
```

---

## 🧪 Etapa 6: Validação de Anotações

Verificar se todas as anotações estão presentes:

### Usuario.java
- ✓ `@Entity`
- ✓ `@Table(name = "usuarios")`
- ✓ `@Data`
- ✓ `@NoArgsConstructor`
- ✓ `@AllArgsConstructor`
- ✓ `@Id`
- ✓ `@GeneratedValue(strategy = GenerationType.IDENTITY)`
- ✓ `@Column`
- ✓ `@OneToMany`

### Produto.java
- ✓ `@Entity`
- ✓ `@Table(name = "produtos")`
- ✓ `@Data`
- ✓ `@NoArgsConstructor`
- ✓ `@AllArgsConstructor`
- ✓ `@Id`
- ✓ `@GeneratedValue(strategy = GenerationType.IDENTITY)`
- ✓ `@Column`
- ✓ `@OneToMany`

### MovimentacaoEstoque.java
- ✓ `@Entity`
- ✓ `@Table(name = "movimentacoes_estoque")`
- ✓ `@Data`
- ✓ `@NoArgsConstructor`
- ✓ `@AllArgsConstructor`
- ✓ `@Id`
- ✓ `@GeneratedValue(strategy = GenerationType.IDENTITY)`
- ✓ `@Column`
- ✓ `@Enumerated(EnumType.STRING)`
- ✓ `@ManyToOne`
- ✓ `@JoinColumn`

### Repositories
- ✓ Estendem `JpaRepository`
- ✓ Com anotação `@Repository`
- ✓ Métodos customizados bem definidos

### Controllers
- ✓ `@Autowired` nos repositories
- ✓ Injeção correta de dependência

---

## 📊 Etapa 7: Validação de Relacionamentos

### Diagrama Esperado

```
Usuario (1) ──────── (N) MovimentacaoEstoque
  |
  └── Relacionamento @OneToMany
      Mapeado por: movimentacoes

Produto (1) ──────── (N) MovimentacaoEstoque
  |
  └── Relacionamento @OneToMany
      Mapeado por: movimentacoes
```

### Verificação SQL

```sql
-- Verificar foreign keys criadas
SELECT CONSTRAINT_NAME, TABLE_NAME, COLUMN_NAME, REFERENCED_TABLE_NAME, REFERENCED_COLUMN_NAME
FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE
WHERE TABLE_NAME = 'movimentacoes_estoque' 
  AND REFERENCED_TABLE_NAME IS NOT NULL;
```

**Esperado:**
- `id_produto` → `produtos.id_produto`
- `id_usuario` → `usuarios.id_usuario`

---

## ☑️ Checklist Final

- [ ] Projeto compila sem erros
- [ ] MySQL cria banco de dados automaticamente
- [ ] Tabelas criadas com Hibernate (ddl-auto=update)
- [ ] Aplicação inicia sem erros
- [ ] Controllers acessíveis nos endpoints esperados
- [ ] Repositories injetados nos controllers
- [ ] Entidades com anotações corretas
- [ ] Relacionamentos (1:N) configurados
- [ ] Enum TipoMovimentacao funcionando
- [ ] Testes passando
- [ ] Foreign keys criadas
- [ ] Índices criados nas colunas

---

## 🐛 Solução de Problemas

### Problema: Column name not found
**Solução:** Verificar se o `@Column(name = "...")` está correto na entidade

### Problema: A entidade não é reconhecida
**Solução:** Verificar se está no pacote correto e com anotação `@Entity`

### Problema: Repository não injetar
**Solução:** Verificar se extends `JpaRepository` e tem `@Repository`

### Problema: Banco não cria tabelas
**Solução:** Verificar `application.properties`:
```properties
spring.jpa.hibernate.ddl-auto=update
spring.jpa.generate-ddl=true
```

### Problema: Column unique constraint violated
**Solução:** Limpar banco ou inserir valores únicos para login

---

## 📚 Referências

- [Spring Data JPA](https://spring.io/projects/spring-data-jpa)
- [Hibernate Documentation](https://hibernate.org)
- [Lombok Project](https://projectlombok.org)
- [MySQL Documentation](https://dev.mysql.com/doc)


