# ⚙️ GUIA DE CONFIGURAÇÃO - BANCO DE DADOS E AMBIENTE

---

## 🗄️ Configuração do MySQL

### Pré-Requisitos
- MySQL 8.0 ou superior instalado
- MySQL rodando em `localhost:3306`
- Usuário `root` criado
- Senha: `Senai@2024`

### Verificar Instalação

```bash
# Verificar versão do MySQL
mysql --version

# Conectar ao MySQL
mysql -u root -p

# Digite a senha: Senai@2024
```

### Criar Usuário (se necessário)

```sql
-- Se não tiver usuário root, crie:
CREATE USER 'root'@'localhost' IDENTIFIED BY 'Senai@2024';
GRANT ALL PRIVILEGES ON *.* TO 'root'@'localhost' WITH GRANT OPTION;
FLUSH PRIVILEGES;
```

### Verificar Banco de Dados

```sql
-- Conectado como root, execute:
SHOW DATABASES;

-- Você deve ver:
-- | CafeAromaESabor | (será criado automaticamente na primeira execução)
```

---

## 🔧 Configuração do application.properties

### Arquivo Local
```
src/main/resources/application.properties
```

### Configurações Principais

| Configuração | Valor | Descrição |
|---|---|---|
| `spring.datasource.url` | jdbc:mysql://localhost:3306/CafeAromaESabor | Servidor local, porta 3306 |
| `spring.datasource.username` | root | Usuário padrão |
| `spring.datasource.password` | Senai@2024 | Senha configurada |
| `spring.jpa.hibernate.ddl-auto` | update | Cria/atualiza tabelas automaticamente |
| `server.port` | 8080 | Porta do servidor Spring |

---

## 🌍 Variáveis de Ambiente (Opcional)

Para ambiente de produção, use variáveis:

```bash
# Windows PowerShell
$env:SPRING_DATASOURCE_URL="jdbc:mysql://localhost:3306/CafeAromaESabor"
$env:SPRING_DATASOURCE_USERNAME="root"
$env:SPRING_DATASOURCE_PASSWORD="Senai@2024"

# Linux/Mac
export SPRING_DATASOURCE_URL=jdbc:mysql://localhost:3306/CafeAromaESabor
export SPRING_DATASOURCE_USERNAME=root
export SPRING_DATASOURCE_PASSWORD=Senai@2024
```

---

## 🧪 Testes de Conexão

### Teste 1: Maven Compile
```bash
mvn clean compile
# Deve mostrar: BUILD SUCCESS
```

### Teste 2: Aplicação Iniciando
```bash
mvn spring-boot:run
# Deve mostrar: Tomcat started on port(s): 8080
```

### Teste 3: Banco Criado
```bash
mysql -u root -p
USE CafeAromaESabor;
SHOW TABLES;
# Deve mostrar: 3 tables (usuarios, produtos, movimentacoes_estoque)
```

### Teste 4: HTTP Request
```bash
curl http://localhost:8080/login
# Deve retornar a página HTML de login
```

---

## 📋 Troubleshooting

### ❌ Erro: "Access denied for user 'root'"

**Solução:**
```bash
# Verificar credenciais em application.properties
spring.datasource.username=root
spring.datasource.password=Senai@2024

# Se ainda não funcionar, resete a senha:
mysql -u root
DROP USER 'root'@'localhost';
CREATE USER 'root'@'localhost' IDENTIFIED BY 'Senai@2024';
GRANT ALL PRIVILEGES ON *.* TO 'root'@'localhost';
FLUSH PRIVILEGES;
```

### ❌ Erro: "Port 8080 already in use"

**Solução:**
```bash
# Mudar porta em application.properties
server.port=8081

# Ou encontrar e matar processo na porta 8080
# Windows:
netstat -ano | findstr :8080
taskkill /PID <PID> /F

# Linux/Mac:
lsof -i :8080
kill -9 <PID>
```

### ❌ Erro: "Cannot drop table"

**Solução:**
```sql
-- Deletar banco e deixar Hibernate criar novo
DROP DATABASE CafeAromaESabor;
-- Execute a aplicação novamente: mvn spring-boot:run
```

### ❌ Erro: "UTF-8 encoding"

**Solução:** Já está configurado em `application.properties`:
```ini
spring.web.encoding.charset=UTF-8
spring.web.encoding.enabled=true
spring.web.encoding.force=true
```

---

## 🔐 Credenciais de Acesso

### Banco de Dados (MySQL)
```
Host: localhost
Porta: 3306
Usuário: root
Senha: Senai@2024
Database: CafeAromaESabor (criado automaticamente)
```

### Aplicação Spring Boot
```
URL: http://localhost:8080/
Login Page: http://localhost:8080/login
Home Page: http://localhost:8080/home
Produtos: http://localhost:8080/produto
Estoque: http://localhost:8080/estoque
```

---

## 📊 Verificar Logs de Inicialização

### Procure por msgs como:

```
[INFO] Starting CafeAromaESabor Application
[INFO] Tomcat started on port(s): 8080 (http)
[DEBUG] Hibernate: create table usuarios ...
[DEBUG] Hibernate: create table produtos ...
[DEBUG] Hibernate: create table movimentacoes_estoque ...
[INFO] Started CafeAromaESabor in X.XXX seconds
```

✅ Se ver essas mensagens, está funcionando!

---

## 🎯 Checklist Pré-Execução

- [ ] MySQL rodando
- [ ] Conexão testada com `mysql -u root -p`
- [ ] Java 17+ instalado (`java -version`)
- [ ] Maven instalado (`mvn -version`)
- [ ] Git clonado/projeto disponível
- [ ] Pasta correta: `C:\Users\TIDEV41\Documents\Spring SR 26\CafeAromaESabor`
- [ ] application.properties verificado
- [ ] Porta 8080 disponível

---

## 🚀 Executar com Segurança

### Passo 1: Verificar Tudo
```bash
java -version                  # Verificar Java
mvn -version                   # Verificar Maven
mysql -u root -p -e "SHOW DATABASES;"  # Verificar MySQL
```

### Passo 2: Compilar
```bash
mvn clean compile -q
```

### Passo 3: Executar
```bash
mvn spring-boot:run
```

### Passo 4: Confirmar
```
Abra: http://localhost:8080/login
```

---

## 💾 Backup do Banco

### Fazer backup
```bash
mysqldump -u root -p CafeAromaESabor > backup.sql
# Digitará a senha: Senai@2024
```

### Restaurar backup
```bash
mysql -u root -p CafeAromaESabor < backup.sql
```

---

## 🔄 Reiniciar Banco (Zerar Dados)

```sql
USE CafeAromaESabor;

-- Desabilitar verificação de FK
SET FOREIGN_KEY_CHECKS = 0;

-- Deletar todos os dados
TRUNCATE TABLE movimentacoes_estoque;
TRUNCATE TABLE usuarios;
TRUNCATE TABLE produtos;

-- Reabilitar verificação
SET FOREIGN_KEY_CHECKS = 1;

-- Verificar
SELECT COUNT(*) FROM usuarios;
SELECT COUNT(*) FROM produtos;
SELECT COUNT(*) FROM movimentacoes_estoque;
```

---

## 📝 Logs Úteis

### Ver SQL gerado
```
logging.level.org.hibernate.SQL=DEBUG
```

### Ver parâmetros de SQL
```
logging.level.org.hibernate.type.descriptor.sql.BasicBinder=TRACE
```

Ambos já estão configurados em `application.properties`!

---

## ✅ Status Depois Pronto

```
✓ Banco MySQL: CONECTADO
✓ Tabelas: CRIADAS AUTOMATICAMENTE
✓ Servidor: RODANDO EM 8080
✓ Aplicação: FUNCIONANDO
✓ Pronto para uso: YES!
```

---

**Tudo configurado? Execute:** 
```bash
mvn spring-boot:run
```


