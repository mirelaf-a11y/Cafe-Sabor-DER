-- ================================================
-- SCHEMA DO BANCO DE DADOS - CAFE AROMA E SABOR
-- ================================================
--
-- Este arquivo mostra a estrutura das tabelas
-- que serão criadas automaticamente pelo Hibernate
-- baseado nas entidades JPA
--

-- ================================================
-- TABELA: usuarios
-- ================================================
-- Armazena os usuários do sistema
-- Auto-criada pelo JPA/Hibernate

CREATE TABLE usuarios (
    id_usuario BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    login VARCHAR(50) NOT NULL UNIQUE,
    senha VARCHAR(255) NOT NULL,
    CONSTRAINT uk_usuarios_login UNIQUE (login)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Índices
CREATE INDEX idx_usuarios_login ON usuarios(login);

-- ================================================
-- TABELA: produtos
-- ================================================
-- Armazena os produtos do sistema de estoque

CREATE TABLE produtos (
    id_produto BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(150) NOT NULL,
    descricao LONGTEXT,
    estoque_minimo INT NOT NULL,
    lote VARCHAR(50),
    data_validade DATE,
    quantidade_atual INT NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Índices
CREATE INDEX idx_produtos_nome ON produtos(nome);
CREATE INDEX idx_produtos_quantidade ON produtos(quantidade_atual);

-- ================================================
-- TABELA: movimentacoes_estoque
-- ================================================
-- Registra as entradas e saídas de produtos

CREATE TABLE movimentacoes_estoque (
    id_movimentacao BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    tipo_movimentacao VARCHAR(10) NOT NULL,
    quantidade INT NOT NULL,
    data_movimentacao DATETIME NOT NULL,
    id_produto BIGINT NOT NULL,
    id_usuario BIGINT NOT NULL,
    CONSTRAINT fk_movimentacoes_produto FOREIGN KEY (id_produto)
        REFERENCES produtos(id_produto) ON DELETE CASCADE,
    CONSTRAINT fk_movimentacoes_usuario FOREIGN KEY (id_usuario)
        REFERENCES usuarios(id_usuario) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Índices
CREATE INDEX idx_movimentacoes_produto ON movimentacoes_estoque(id_produto);
CREATE INDEX idx_movimentacoes_usuario ON movimentacoes_estoque(id_usuario);
CREATE INDEX idx_movimentacoes_tipo ON movimentacoes_estoque(tipo_movimentacao);
CREATE INDEX idx_movimentacoes_data ON movimentacoes_estoque(data_movimentacao);

-- ================================================
-- RELACIONAMENTOS
-- ================================================

-- Foreign Key: movimentacoes_estoque.id_produto -> produtos.id_produto
ALTER TABLE movimentacoes_estoque
ADD CONSTRAINT fk_mov_estoque_produto
FOREIGN KEY (id_produto) REFERENCES produtos(id_produto)
ON DELETE CASCADE
ON UPDATE CASCADE;

-- Foreign Key: movimentacoes_estoque.id_usuario -> usuarios.id_usuario
ALTER TABLE movimentacoes_estoque
ADD CONSTRAINT fk_mov_estoque_usuario
FOREIGN KEY (id_usuario) REFERENCES usuarios(id_usuario)
ON DELETE CASCADE
ON UPDATE CASCADE;

-- ================================================
-- DADOS DE EXEMPLO (OPCIONAL)
-- ================================================

-- Inserir usuários de exemplo
INSERT INTO usuarios (nome, login, senha) VALUES
('João Silva', 'joao.silva', 'senha123'),
('Maria Santos', 'maria.santos', 'senha456'),
('Pedro Oliveira', 'pedro.oliveira', 'senha789');

-- Inserir produtos de exemplo
INSERT INTO produtos (nome, descricao, estoque_minimo, lote, data_validade, quantidade_atual) VALUES
('Café Premium Arábica', 'Café 100% arábica de alta qualidade', 50, 'LOTE001', '2026-12-31', 150),
('Café Robusta', 'Café robusta para bebidas fortes', 30, 'LOTE002', '2026-11-30', 80),
('Café Descafeinado', 'Café descafeinado premium', 20, 'LOTE003', '2026-10-31', 45),
('Açúcar Cristal', 'Açúcar cristal refinado', 100, 'LOTE004', '2027-06-30', 200),
('Leite em Pó', 'Leite integral em pó', 40, 'LOTE005', '2026-09-30', 60);

-- ================================================
-- VIEWS ÚTEIS (OPCIONAL)
-- ================================================

-- View: Histórico de Movimentações com Detalhes
CREATE VIEW vw_historico_movimentacoes AS
SELECT
    m.id_movimentacao,
    p.nome AS produto_nome,
    u.nome AS usuario_nome,
    m.tipo_movimentacao,
    m.quantidade,
    m.data_movimentacao,
    p.quantidade_atual
FROM movimentacoes_estoque m
JOIN produtos p ON m.id_produto = p.id_produto
JOIN usuarios u ON m.id_usuario = u.id_usuario
ORDER BY m.data_movimentacao DESC;

-- View: Produtos com Estoque Crítico
CREATE VIEW vw_estoque_critico AS
SELECT
    id_produto,
    nome,
    quantidade_atual,
    estoque_minimo,
    (estoque_minimo - quantidade_atual) AS diferenca
FROM produtos
WHERE quantidade_atual <= estoque_minimo
ORDER BY quantidade_atual ASC;

-- View: Resumo de Movimentações por Produto
CREATE VIEW vw_resumo_movimentacoes_produto AS
SELECT
    p.id_produto,
    p.nome,
    COUNT(CASE WHEN m.tipo_movimentacao = 'ENTRADA' THEN 1 END) AS total_entradas,
    SUM(CASE WHEN m.tipo_movimentacao = 'ENTRADA' THEN m.quantidade ELSE 0 END) AS qtd_total_entradas,
    COUNT(CASE WHEN m.tipo_movimentacao = 'SAIDA' THEN 1 END) AS total_saidas,
    SUM(CASE WHEN m.tipo_movimentacao = 'SAIDA' THEN m.quantidade ELSE 0 END) AS qtd_total_saidas
FROM produtos p
LEFT JOIN movimentacoes_estoque m ON p.id_produto = m.id_produto
GROUP BY p.id_produto, p.nome;

-- ================================================
-- CONSULTAS ÚTEIS
-- ================================================

-- 1. Listar todos os produtos com estoque crítico
SELECT nome, quantidade_atual, estoque_minimo
FROM produtos
WHERE quantidade_atual <= estoque_minimo;

-- 2. Contar movimentações por tipo
SELECT tipo_movimentacao, COUNT(*) as total
FROM movimentacoes_estoque
GROUP BY tipo_movimentacao;

-- 3. Listar movimentações do último mês
SELECT m.*, p.nome, u.nome
FROM movimentacoes_estoque m
JOIN produtos p ON m.id_produto = p.id_produto
JOIN usuarios u ON m.id_usuario = u.id_usuario
WHERE m.data_movimentacao >= DATE_SUB(NOW(), INTERVAL 1 MONTH)
ORDER BY m.data_movimentacao DESC;

-- 4. Saldo de um produto específico
SELECT
    nome,
    SUM(CASE WHEN tipo_movimentacao = 'ENTRADA' THEN quantidade
             WHEN tipo_movimentacao = 'SAIDA' THEN -quantidade
             ELSE 0 END) AS saldo_movimentacoes
FROM movimentacoes_estoque m
JOIN produtos p ON m.id_produto = p.id_produto
WHERE m.id_produto = 1
GROUP BY m.id_produto, p.nome;

-- 5. Movimentações de um usuário específico
SELECT m.*, p.nome, m.tipo_movimentacao, m.quantidade, m.data_movimentacao
FROM movimentacoes_estoque m
JOIN produtos p ON m.id_produto = p.id_produto
WHERE m.id_usuario = 1
ORDER BY m.data_movimentacao DESC;

-- ================================================
-- MANUTENÇÃO
-- ================================================

-- Verificar integridade das foreign keys
SELECT CONSTRAINT_NAME, TABLE_NAME, REFERENCED_TABLE_NAME
FROM INFORMATION_SCHEMA.REFERENTIAL_CONSTRAINTS
WHERE CONSTRAINT_SCHEMA = 'CafeAromaESabor';

-- Contar registros
SELECT 'usuarios' as tabela, COUNT(*) FROM usuarios
UNION ALL
SELECT 'produtos', COUNT(*) FROM produtos
UNION ALL
SELECT 'movimentacoes_estoque', COUNT(*) FROM movimentacoes_estoque;

-- Verificar espaço utilizado
SELECT
    table_name,
    ROUND(((data_length + index_length) / 1024 / 1024), 2) AS 'Size (MB)'
FROM information_schema.TABLES
WHERE table_schema = 'CafeAromaESabor'
ORDER BY (data_length + index_length) DESC;

