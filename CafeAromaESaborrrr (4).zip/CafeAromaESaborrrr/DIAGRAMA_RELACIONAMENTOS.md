# 🔗 Diagrama de Relacionamentos JPA - Café Aroma e Sabor

## 📊 Diagrama Entidade-Relacionamento (ER)

```
┌─────────────────────┐                    ┌──────────────────────┐
│      Usuario        │                    │      Produto         │
├─────────────────────┤                    ├──────────────────────┤
│ PK id_usuario       │ 1                 │ PK id_produto        │
│    nome             │───────┐           │    nome              │
│    login            │       │ N         │    descricao         │
│    senha            │       └─┬─────────┼── estoque_minimo    │
└─────────────────────┘         │         │    lote              │
                                │         │    data_validade     │
                                │         │    quantidade_atual  │
                                │         └──────────────────────┘
                                │                    ▲
                                │                    │
                                │         ┌──────────┘
                                │         │
                         1      │ N       │  1
    ┌────────────────────────────────────┴──────────┐
    │   MovimentacaoEstoque                        │
    ├────────────────────────────────────────────────┤
    │ PK id_movimentacao                           │
    │    tipo_movimentacao (ENTRADA|SAIDA)         │
    │    quantidade                                │
    │    data_movimentacao                         │
    │ FK id_usuario (ManyToOne → Usuario)          │
    │ FK id_produto (ManyToOne → Produto)          │
    └────────────────────────────────────────────────┘
```

---

## 🏆 Relacionamentos por Entidade

### **1. USUARIO → MOVIMENTAÇÃO** (1:N)

**Tipo:** OneToMany (lado da chave primária)

```java
// Em Usuario.java
@OneToMany(
    mappedBy = "usuario",           // Campo em MovimentacaoEstoque
    cascade = CascadeType.ALL,      // Propaga operações
    orphanRemoval = true            // Remove registros órfãos
)
private List<MovimentacaoEstoque> movimentacoes;
```

**O que isso significa:**
- ✅ Um usuário pode fazer MUITAS movimentações
- ✅ Se deletar usuário → deleta suas movimentações
- ✅ Se remover movimentação da lista → deleta do DB

**Exemplo:**
```
Usuario "João"
  ├─ Movimentação 1: +10 Café (ENTRADA)
  ├─ Movimentação 2: -5 Pão de Queijo (SAIDA)
  ├─ Movimentação 3: +20 Croissant (ENTRADA)
  └─ Movimentação N: ...
```

---

### **2. PRODUTO → MOVIMENTAÇÃO** (1:N)

**Tipo:** OneToMany (lado da chave primária)

```java
// Em Produto.java
@OneToMany(
    mappedBy = "produto",
    cascade = CascadeType.ALL,
    orphanRemoval = true
)
private List<MovimentacaoEstoque> movimentacoes;
```

**O que isso significa:**
- ✅ Um produto pode ter MUITAS movimentações
- ✅ Histórico completo de entrada/saída
- ✅ Se deletar produto → deleta histórico de movimentações

**Exemplo:**
```
Produto "Café Premium"
  ├─ Movimentação 1: +1000 pacotes (João, 10/03/2026)
  ├─ Movimentação 2: -150 pacotes (Maria, 12/03/2026)
  ├─ Movimentação 3: +500 pacotes (Pedro, 15/03/2026)
  └─ Movimentação N: ...
```

---

### **3. MOVIMENTAÇÃO → USUÁRIO** (N:1)

**Tipo:** ManyToOne (lado da chave estrangeira)

```java
// Em MovimentacaoEstoque.java
@ManyToOne(fetch = FetchType.LAZY)
@JoinColumn(name = "id_usuario", nullable = false)
private Usuario usuario;
```

**O que isso significa:**
- ✅ MUITAS movimentações pertencem a UM usuário
- ✅ Sempre carregado via FK (id_usuario)
- ✅ FetchType.LAZY → carrega apenas quando acessado

**Exemplo:**
```
Movimentacao 1 → usuario: João
Movimentacao 2 → usuario: João
Movimentacao 3 → usuario: Maria
Movimentacao 4 → usuario: João
```

---

### **4. MOVIMENTAÇÃO → PRODUTO** (N:1)

**Tipo:** ManyToOne (lado da chave estrangeira)

```java
// Em MovimentacaoEstoque.java
@ManyToOne(fetch = FetchType.LAZY)
@JoinColumn(name = "id_produto", nullable = false)
private Produto produto;
```

**O que isso significa:**
- ✅ MUITAS movimentações pertencem a UM produto
- ✅ Sempre carregado via FK (id_produto)
- ✅ FetchType.LAZY → carrega apenas quando acessado

**Exemplo:**
```
Movimentacao 1 → produto: Café Premium
Movimentacao 2 → produto: Pão de Queijo
Movimentacao 3 → produto: Café Premium
Movimentacao 4 → produto: Croissant
```

---

## 💾 Configuração CASCADE

### **CascadeType.ALL → O que propaga?**

```
┌─ CascadeType.PERSIST
│  └─ Ao salvar Usuario, salva também suas Movimentações
│
├─ CascadeType.MERGE
│  └─ Ao atualizar Usuario, atualiza também suas Movimentações
│
├─ CascadeType.REMOVE
│  └─ Ao deletar Usuario, deleta também suas Movimentações
│
├─ CascadeType.REFRESH
│  └─ Ao recarregar Usuario, recarrega suas Movimentações
│
└─ CascadeType.DETACH → parte de ALL
   └─ Ao desanexar Usuario, desanexa suas Movimentações
```

---

## ⚡ FetchType LAZY vs EAGER

### **FetchType.LAZY** (Recomendado)
```java
@ManyToOne(fetch = FetchType.LAZY)
@JoinColumn(name = "id_usuario")
private Usuario usuario;
```

**Vantagens:**
- ✅ Melhor performance
- ✅ Carrega dados apenas quando necessário
- ✅ Menos dados em memória

**Quando usar:**
- Consultas com muitos registros
- Dados relacionados nem sempre necessários

**Exemplo:**
```java
MovimentacaoEstoque mov = db.findById(1);  // Apenas mov, sem usuario
String nomeUsuario = mov.getUsuario().getNome();  // Aqui carrega usuario
```

---

### **FetchType.EAGER**
```java
@ManyToOne(fetch = FetchType.EAGER)
@JoinColumn(name = "id_usuario")
private Usuario usuario;
```

**Vantagens:**
- ✅ Dados sempre carregados
- ✅ Não causa LazyInitializationException

**Desvantagens:**
- ❌ Menor performance
- ❌ Consome mais memória
- ❌ N+1 Query Problem

---

## 📋 Operações de Cascata - Exemplos Práticos

### **Exemplo 1: Salvar com Cascata**

```java
// Criar usuário
Usuario usuario = new Usuario();
usuario.setNome("João Silva");
usuario.setLogin("joao");
usuario.setSenha("123456");

// Criar movimentações
MovimentacaoEstoque mov1 = new MovimentacaoEstoque();
mov1.setQuantidade(10);
mov1.setTipoMovimentacao(TipoMovimentacao.ENTRADA);

MovimentacaoEstoque mov2 = new MovimentacaoEstoque();
mov2.setQuantidade(5);
mov2.setTipoMovimentacao(TipoMovimentacao.SAIDA);

// Adicionar à lista
List<MovimentacaoEstoque> movs = new ArrayList<>();
movs.add(mov1);
movs.add(mov2);
usuario.setMovimentacoes(movs);

// Salvar (cascata salva tudo!)
usuarioRepository.save(usuario);

// Resultado no DB: 1 Usuario + 2 Movimentacoes inseridas
```

---

### **Exemplo 2: Deletar com Cascata**

```java
// Buscar usuário
Optional<Usuario> usuarioOpt = usuarioRepository.findById(1L);

if (usuarioOpt.isPresent()) {
    Usuario usuario = usuarioOpt.get();
    
    // Deletar usuário - cascata deleta TODAS suas movimentações
    usuarioRepository.delete(usuario);
    
    // Resultado no DB: Usuario deletado + todas suas Movimentacoes deletadas
}
```

---

### **Exemplo 3: Remover Órfão com orphanRemoval**

```java
// Buscar usuário
Usuario usuario = usuarioRepository.findById(1L).orElse(null);

// Remover movimentação da lista
if (usuario != null && !usuario.getMovimentacoes().isEmpty()) {
    usuario.getMovimentacoes().remove(0);
    
    // Salvar - orphanRemoval = true faz com que a movimentação removed seja deletada
    usuarioRepository.save(usuario);
    
    // Resultado no DB: Movimentacao deletada mesmo sem cascata REMOVE explícita
}
```

---

## 🔍 Queries Automáticas dos Repositórios

### **Query Derivada - ProdutoRepository**

```java
// Método: findByNomeContainingIgnoreCase(String nome)
// SQL gerado: SELECT * FROM produtos WHERE UPPER(nome) LIKE UPPER('%' + ? + '%')
List<Produto> cafes = produtoRepository.findByNomeContainingIgnoreCase("café");
// Resultado: ["Café Premium", "Café Especial", "Café Coado"]
```

---

### **Query Derivada - ProdutoRepository**

```java
// Método: findByQuantidadeAtualLessThanEqual(Integer quantidade)
// SQL gerado: SELECT * FROM produtos WHERE quantidade_atual <= ?
List<Produto> criticos = produtoRepository.findByQuantidadeAtualLessThanEqual(50);
// Resultado: Todos produtos com quantidade <= 50
```

---

### **Query Derivada - MovimentacaoEstoqueRepository**

```java
// Método: findByProdutoId(Long produtoId)
// SQL gerado: SELECT * FROM movimentacoes_estoque WHERE id_produto = ?
List<MovimentacaoEstoque> movs = movimentacaoEstoqueRepository.findByProdutoId(1L);
// Resultado: Histórico completo do produto 1
```

---

### **Query Derivada - MovimentacaoEstoqueRepository**

```java
// Método: findByTipoMovimentacao(TipoMovimentacao tipo)
// SQL gerado: SELECT * FROM movimentacoes_estoque WHERE tipo_movimentacao = ?
List<MovimentacaoEstoque> entradas = 
    movimentacaoEstoqueRepository.findByTipoMovimentacao(TipoMovimentacao.ENTRADA);
// Resultado: Todas as entradas de estoque
```

---

### **Query Derivada - MovimentacaoEstoqueRepository**

```java
// Método: findByProdutoIdAndTipoMovimentacao(Long produtoId, TipoMovimentacao tipo)
// SQL gerado: SELECT * FROM movimentacoes_estoque 
//             WHERE id_produto = ? AND tipo_movimentacao = ?
List<MovimentacaoEstoque> entradas = 
    movimentacaoEstoqueRepository.findByProdutoIdAndTipoMovimentacao(
        1L, 
        TipoMovimentacao.ENTRADA
    );
// Resultado: Entradas do produto 1
```

---

## 🚨 Problemas Comuns e Soluções

### **Problema 1: LazyInitializationException**

```java
// ❌ ERRO
MovimentacaoEstoque mov = movimentacaoEstoqueRepository.findById(1L).orElse(null);
String nomeUsuario = mov.getUsuario().getNome();  // Erro se sessão fechou
```

**Soluções:**
```java
// ✅ Solução 1: Usar fetchType.EAGER
@ManyToOne(fetch = FetchType.EAGER)
private Usuario usuario;

// ✅ Solução 2: Acessar dentro da transação
@Transactional
public void exemplo() {
    MovimentacaoEstoque mov = movimentacaoEstoqueRepository.findById(1L).orElse(null);
    String nomeUsuario = mov.getUsuario().getNome();  // OK
}

// ✅ Solução 3: Usar Join Fetch
// @Query(value = "SELECT m FROM MovimentacaoEstoque m JOIN FETCH m.usuario")
// List<MovimentacaoEstoque> findAllWithUsuario();
```

---

### **Problema 2: N+1 Query Problem**

```java
// ❌ INEFICIENTE
List<MovimentacaoEstoque> movs = movimentacaoEstoqueRepository.findAll();
for (MovimentacaoEstoque mov : movs) {
    System.out.println(mov.getUsuario().getNome());  // 1 query por linha!
}
// Total: 1 query findAll() + N queries para cada usuario (N+1)
```

**Soluções:**
```java
// ✅ Solução 1: Usar @Query com FETCH JOIN
@Query("SELECT DISTINCT m FROM MovimentacaoEstoque m " +
       "JOIN FETCH m.usuario " +
       "JOIN FETCH m.produto")
List<MovimentacaoEstoque> findAllWithJoin();

// ✅ Solução 2: Usar Spring Data JPA @EntityGraph
@EntityGraph(attributePaths = {"usuario", "produto"})
@Override
List<MovimentacaoEstoque> findAll();
```

---

### **Problema 3: Deletar com Constraint**

```java
// ❌ ERRO
Produto produto = produtoRepository.findById(1L).orElse(null);
produtoRepository.delete(produto);
// Erro: Cannot delete produto pois tem movimentacoes
```

**Solução: Garantir orphanRemoval = true**
```java
// ✅ Em Produto.java
@OneToMany(
    mappedBy = "produto",
    cascade = CascadeType.ALL,
    orphanRemoval = true  // ← Isso resolve!
)
private List<MovimentacaoEstoque> movimentacoes;

// Agora delete funciona
produtoRepository.delete(produto);  // ✅ OK
```

---

## 📚 Padrões de Uso Recomendados

### **Padrão 1: Buscar com Relacionamentos**

```java
@Repository
public interface MovimentacaoEstoqueRepository extends JpaRepository<MovimentacaoEstoque, Long> {
    
    @Query("SELECT m FROM MovimentacaoEstoque m " +
           "JOIN FETCH m.usuario u " +
           "JOIN FETCH m.produto p " +
           "WHERE u.id = :usuarioId")
    List<MovimentacaoEstoque> findByUsuarioIdWithRelations(@Param("usuarioId") Long usuarioId);
}
```

---

### **Padrão 2: Paginação com Repositório**

```java
@Repository
public interface ProdutoRepository extends JpaRepository<Produto, Long> {
    
    /**
     * Retorna produtos em páginas de tamanho definido
     */
    Page<Produto> findAll(Pageable pageable);
    
    /**
     * Busca com paginação
     */
    Page<Produto> findByNomeContainingIgnoreCase(String nome, Pageable pageable);
}

// Uso:
Page<Produto> pagina1 = produtoRepository.findAll(
    PageRequest.of(0, 10, Sort.by("nome").ascending())
);
```

---

## ✅ Checklist Final

- [x] Relacionamento 1:N Usuario → Movimentacao
- [x] Relacionamento 1:N Produto → Movimentacao
- [x] Relacionamento N:1 Movimentacao → Usuario
- [x] Relacionamento N:1 Movimentacao → Produto
- [x] CascadeType.ALL configurado
- [x] orphanRemoval = true configurado
- [x] FetchType.LAZY para melhor performance
- [x] @Repository em todos os repositórios
- [x] JpaRepository como superclasse
- [x] Métodos derivados em repositórios
- [x] @Autowired nos controllers
- [x] Sem LazyInitializationException
- [x] SQL correto gerado pelo Hibernate

---

**Implementação:** ✅ COMPLETA E FUNCIONAL


