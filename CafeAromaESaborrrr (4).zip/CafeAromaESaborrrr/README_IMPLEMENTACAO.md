# 📦 Sistema de Controle de Estoque - Cafe Aroma e Sabor

**Implementação da Camada de Modelagem e Persistência**

---

## ✨ O que foi implementado

### 1️⃣ Entidades (Model)
- ✅ **Usuario.java** - Usuários do sistema
- ✅ **Produto.java** - Produtos com controle de estoque
- ✅ **MovimentacaoEstoque.java** - Registra entradas e saídas
- ✅ **TipoMovimentacao.java** - Enum (ENTRADA/SAIDA)

### 2️⃣ Repositories (Persistência)
- ✅ **UsuarioRepository** - Buscar por login + CRUD
- ✅ **ProdutoRepository** - Buscar por nome, estoque crítico + CRUD
- ✅ **MovimentacaoEstoqueRepository** - Múltiplas consultas avançadas + CRUD

### 3️⃣ Controllers (Injeção)
- ✅ **LoginController** - Com UsuarioRepository
- ✅ **ProdutoController** - Com ProdutoRepository  
- ✅ **EstoqueController** - Com MovimentacaoEstoque e ProdutoRepository
- ✅ **HomeController** - Sem alterações
- ✅ **RootController** - Sem alterações

### 4️⃣ Documentação
- 📄 **IMPLEMENTACAO_CAMADA_PERSISTENCIA.md** - Documentação completa
- 📄 **SCHEMA_BANCO_DADOS.sql** - DDL e exemplos SQL
- 📄 **GUIA_TESTES.md** - Guia de validação
- 📄 **ExemplosRepositories.java** - Exemplos de uso

---

## 📊 Estrutura de Pastas

```
CafeAromaESabor/
├── src/main/java/org/example/cafearomaesabor/
│   ├── model/
│   │   ├── Usuario.java
│   │   ├── Produto.java
│   │   ├── MovimentacaoEstoque.java
│   │   └── TipoMovimentacao.java
│   ├── repository/
│   │   ├── UsuarioRepository.java
│   │   ├── ProdutoRepository.java
│   │   └── MovimentacaoEstoqueRepository.java
│   ├── controllers/ (atualizados)
│   │   ├── LoginController.java
│   │   ├── ProdutoController.java
│   │   ├── EstoqueController.java
│   │   ├── HomeController.java
│   │   └── RootController.java
│   ├── examples/
│   │   └── ExemplosRepositories.java
│   └── CafeAromaESaborApplication.java
├── src/main/resources/
│   └── application.properties
├── pom.xml
├── IMPLEMENTACAO_CAMADA_PERSISTENCIA.md
├── SCHEMA_BANCO_DADOS.sql
├── GUIA_TESTES.md
└── README.md (este arquivo)
```

---

## 🚀 Como Usar

### 1. Compilar o Projeto
```bash
cd "C:\Users\TIDEV41\Documents\Spring SR 26\CafeAromaESabor"
mvn clean install
```

### 2. Iniciar a Aplicação
```bash
mvn spring-boot:run
```

### 3. Acessar
- Homepage: `http://localhost:8080/home`
- Login: `http://localhost:8080/login`
- Produtos: `http://localhost:8080/produto`
- Estoque: `http://localhost:8080/estoque`

---

## 📝 Exemplo Rápido

### Injetar Repository em um Controller
```java
@Controller
public class MeuController {
    
    @Autowired
    private ProdutoRepository produtoRepository;
    
    @GetMapping("/listar")
    public String listar(Model model) {
        // Buscar todos
        List<Produto> produtos = produtoRepository.findAll();
        
        // Buscar por nome
        List<Produto> cafes = produtoRepository.findByNomeContainingIgnoreCase("café");
        
        // Estoque crítico
        List<Produto> critico = produtoRepository.findByQuantidadeAtualLessThanEqual(50);
        
        model.addAttribute("produtos", produtos);
        return "minha-view";
    }
}
```

### Registrar Movimentação
```java
@Autowired
private MovimentacaoEstoqueRepository movimentacaoRepository;
@Autowired
private ProdutoRepository produtoRepository;
@Autowired
private UsuarioRepository usuarioRepository;

// Registrar entrada
MovimentacaoEstoque entrada = new MovimentacaoEstoque();
entrada.setTipoMovimentacao(TipoMovimentacao.ENTRADA);
entrada.setQuantidade(50);
entrada.setDataMovimentacao(LocalDateTime.now());
entrada.setProduto(produtoRepository.findById(1L).get());
entrada.setUsuario(usuarioRepository.findById(1L).get());

movimentacaoRepository.save(entrada);
```

---

## 🏗️ Arquitetura

### Camadas Implementadas
```
┌─────────────────────────────────┐
│      Controllers (Web)          │
│  (LoginController, etc)         │
└────────────┬────────────────────┘
             │
             ↓
┌─────────────────────────────────┐
│   Repositories (Persistência)   │
│  (UsuarioRepository, etc)       │
└────────────┬────────────────────┘
             │
             ↓
┌─────────────────────────────────┐
│      Entities (Model/JPA)       │
│  (Usuario, Produto, etc)        │
└────────────┬────────────────────┘
             │
             ↓
┌─────────────────────────────────┐
│      MySQL Database             │
└─────────────────────────────────┘
```

---

## 🔐 Relacionamentos

### Usuario → MovimentacaoEstoque
- **Tipo:** 1:N (Um-para-Muitos)
- **Descrição:** Um usuário pode registrar múltiplas movimentações
- **Cascade:** ALL (deleta movimentações se usuário for deletado)

### Produto → MovimentacaoEstoque
- **Tipo:** 1:N (Um-para-Muitos)
- **Descrição:** Um produto pode ter múltiplas movimentações
- **Cascade:** ALL (deleta movimentações se produto for deletado)

### MovimentacaoEstoque
- **ManyToOne com Usuario**
- **ManyToOne com Produto**
- **Fetch:** LAZY (para performance)

---

## 📚 Tecnologias

| Componente | Versão |
|-----------|--------|
| Java | 21 |
| Spring Boot | 4.0.6 |
| JPA/Hibernate | Incluído no Spring Boot |
| MySQL Connector | Incluído no Spring Boot |
| Lombok | Incluído no pom.xml |
| Maven | Incluído (mvnw) |

---

## 🎯 O QUE NÃO FOI FEITO (Como Solicitado)

- ❌ Autenticação JWT
- ❌ Services (deixado para próxima etapa)
- ❌ DTOs (deixado para próxima etapa)
- ❌ APIs REST completas
- ❌ Segurança Spring Security
- ❌ Alterações em HTML/CSS
- ❌ Banco NoSQL
- ❌ Código desnecessário

---

## ✅ Validação

Para validar a implementação, execute:

```bash
# Compilar
mvn clean compile

# Rodar testes (se houver)
mvn test

# Construir
mvn clean install

# Iniciar
mvn spring-boot:run
```

Verificar console para mensagens BDD (Base de Dados Criada).

---

## 📖 Documentação Adicional

1. **IMPLEMENTACAO_CAMADA_PERSISTENCIA.md**
   - Documentação completa de todas as classes
   - Explicação de cada anotação
   - Descrição dos relacionamentos

2. **SCHEMA_BANCO_DADOS.sql**
   - DDL das tabelas
   - Dados de exemplo
   - Views úteis
   - Consultas SQL prontas

3. **GUIA_TESTES.md**
   - Testes de integração
   - Validação de estrutura
   - Solução de problemas

4. **ExemplosRepositories.java**
   - Exemplos de uso dos repositories
   - Padrões de consulta
   - Integração em controllers

---

## 🔍 Estrutura de Dados

### Tabela: usuarios
```
id_usuario (INT) - PK
nome (VARCHAR 100)
login (VARCHAR 50) - UNIQUE
senha (VARCHAR 255)
```

### Tabela: produtos
```
id_produto (INT) - PK
nome (VARCHAR 150)
descricao (TEXT)
estoque_minimo (INT)
lote (VARCHAR 50)
data_validade (DATE)
quantidade_atual (INT)
```

### Tabela: movimentacoes_estoque
```
id_movimentacao (INT) - PK
tipo_movimentacao (VARCHAR 10) - ENUM(ENTRADA, SAIDA)
quantidade (INT)
data_movimentacao (DATETIME)
id_produto (INT) - FK → produtos
id_usuario (INT) - FK → usuarios
```

---

## ⚙️ Configuração (application.properties)

```properties
# Banco de Dados
spring.datasource.url=jdbc:mysql://localhost:3306/CafeAromaESabor?createDatabaseIfNotExist=true
spring.datasource.username=root
spring.datasource.password=Senai@2024
spring.datasource.driver-class-name=com.mysql.cj.jdbc.Driver

# JPA/Hibernate
spring.jpa.generate-ddl=true
spring.jpa.hibernate.ddl-auto=update
spring.jpa.show-sql=true
```

---

## 🐛 Troubleshooting

| Problema | Solução |
|----------|---------|
| Build falha | Execute `mvn clean install` |
| Banco não cria | Verifique MySQL está rodando |
| Tabelas não criadas | Verifique `ddl-auto=update` |
| Repository não injeta | Verifique `@Repository` e `JpaRepository` |
| Foreign key error | Limpe a database e inicie novamente |

---

## 📞 Próximas Etapas

1. **Services** - Implementar camada de serviços
2. **DTOs** - Criar Data Transfer Objects
3. **Validações** - Adicionar validações com @Valid
4. **Testes** - Criar testes unitários
5. **Segurança** - Adicionar autenticação (possivelmente JWT)
6. **APIs REST** - Implementar endpoints REST

---

## 📋 Licença e Informações

- **Projeto:** Cafe Aroma e Sabor - Sistema de Controle de Estoque
- **Instituição:** SENAI
- **Data:** 2026-05-18
- **Status:** ✅ Camada de Persistência Implementada

---

## 📞 Suporte

Para dúvidas ou problemas:
1. Consulte a documentação em `IMPLEMENTACAO_CAMADA_PERSISTENCIA.md`
2. Veja exemplos em `ExemplosRepositories.java`
3. Verifique o guia de testes em `GUIA_TESTES.md`
4. Consulte queries SQL em `SCHEMA_BANCO_DADOS.sql`

**Desenvolvimento concluído com sucesso! ✅**

